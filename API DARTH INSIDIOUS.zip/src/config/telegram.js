module.exports = {
  TOKEN: "8738917654:AAGCoyvWIs6flvE-elzC_1BbTsg-p4gxlsI",
  OWNER_ID: 7744011281, // ID owner sebagai angka
  GROUP_NOTIF_ID: "-1003988184271" // ID grup (dapat diambil dari link grup atau menggunakan bot @userinfobot)
};