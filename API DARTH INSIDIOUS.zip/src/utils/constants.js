module.exports = {
      PORT: process.env.PORT || 1328,
  WS_PORT: process.env.WS_PORT || 1328,
  // WhatsApp bug types
  BUGS: [
    { bug_id: "delayhard", bug_name: "DELAY HARD" },
    { bug_id: "blankclick", bug_name: "BLANK 5 MSG" },
    { bug_id: "buldoxfreze", bug_name: "BULDO × FREZE" },
    { bug_id: "blankui", bug_name: "BLANK ANDRO" },
    { bug_id: "crashandro", bug_name: "CRASH ANDRO" },
    { bug_id: "crashios", bug_name: "CRASH IPHONE" }
  ],
    
  payload: [
    { bug_id: "invisibleSpam", bug_name: "DELAY ANDROID" },
    { bug_id: "forceCloseMentalVVIP", bug_name: "FORCE CLOSE" },
    { bug_id: "stealthCrashVVIP", bug_name: "CRASH ANDROID" },
    { bug_id: "crashNotificationVVIP", bug_name: "CRASH NOTIFIKASI" },
    { bug_id: "permenCall", bug_name: "PRANK CALL" }
  ],
    
  DDOS: [
    { ddos_id: "s-gbps", ddos_name: "SYN High GBPS" },
    { ddos_id: "s-pps", ddos_name: "SYN Traffic Flood" },
    { ddos_id: "a-gbps", ddos_name: "ACK High GBPS" },
    { ddos_id: "a-pps", ddos_name: "ACK Traffic Flood" },
    { ddos_id: "icmp", ddos_name: "ICMP Flood" },
    { ddos_id: "udp", ddos_name: "GUDP ( HIGH RISK )" }

  ],
  // News data
  NEWS: [
    {
      image: "https://files.catbox.moe/keg8g1.jpg",
      title: "DARTH INSIDIOUS",
      desc: "keep growing as time goes by"
    }
  ],
  // Role cooldowns (in seconds)
  ROLE_COOLDOWNS: {
  member: 999999,
  reseller: 60,
  vip: 30,
  admin: 20,
  high_admin: 15,
  owner: 10,
  ceo: 5,
  dev: 0,
},
MAX_QUANTITIES: {
  member: 0,
  reseller: 5,
  vip: 10,
  admin: 10,
  high_admin: 15,
  owner: 50,
  ceo: 100,
  dev: 999,
}
}