const TelegramBot = require("node-telegram-bot-api");
const { logger } = require('../utils/logger');
const { TOKEN, OWNER_ID, GROUP_NOTIF_ID } = require('../config/telegram');
const { loadDatabase, saveDatabase } = require('./databaseService');
const { disconnectAllActiveConnections, startUserSessions } = require('./whatsappService');
const fs = require('fs');
const path = require('path');

const bot = new TelegramBot(TOKEN, { polling: true });

// ========== SISTEM ROLE HIERARKI ==========
const TELEGRAM_ROLE_FILE = path.join(__dirname, '../data/telegram_roles.json');
let telegramRoles = new Map();

// Level role (semakin besar angka, semakin tinggi akses)
const ROLE_LEVEL = {
  'member': 1,
  'vip': 2,
  'reseller': 3,
  'admin': 4,
  'owner': 5,
  'highadmin': 6,
  'ceo': 7,
  'dev': 8
};

// Role yang bisa dibuat oleh masing-masing role
const ROLE_CREATE_PERMISSION = {
  'member': [],
  'vip': [],
  'reseller': ['vip', 'member'],
  'admin': ['reseller', 'vip', 'member'],
  'owner': ['admin', 'reseller', 'vip', 'member'],
  'highadmin': ['owner', 'admin', 'reseller', 'vip', 'member'],
  'ceo': ['highadmin', 'owner', 'admin', 'reseller', 'vip', 'member'],
  'dev': ['ceo', 'highadmin', 'owner', 'admin', 'reseller', 'vip', 'member']
};

// Load role dari file
function loadTelegramRoles() {
  try {
    if (fs.existsSync(TELEGRAM_ROLE_FILE)) {
      const data = JSON.parse(fs.readFileSync(TELEGRAM_ROLE_FILE, 'utf-8'));
      telegramRoles = new Map(Object.entries(data));
      logger.info(`${telegramRoles.size} telegram roles loaded`);
    }
  } catch (error) {
    logger.error(`Gagal load telegram roles: ${error.message}`);
  }
}

function saveTelegramRoles() {
  try {
    const obj = Object.fromEntries(telegramRoles);
    fs.writeFileSync(TELEGRAM_ROLE_FILE, JSON.stringify(obj, null, 2));
  } catch (error) {
    logger.error(`Gagal save telegram roles: ${error.message}`);
  }
}

// Cek role user Telegram
function getUserTelegramRole(userId) {
  return telegramRoles.get(userId)?.role || 'member';
}

// Cek level role user Telegram
function getUserTelegramLevel(userId) {
  const role = getUserTelegramRole(userId);
  return ROLE_LEVEL[role] || 1;
}

// Cek apakah user bisa membuat role tertentu
function canCreateTelegramRole(creatorId, targetRole) {
  const creatorRole = getUserTelegramRole(creatorId);
  const allowedRoles = ROLE_CREATE_PERMISSION[creatorRole] || [];
  return allowedRoles.includes(targetRole);
}

// Cek apakah user punya akses minimal level tertentu
function hasMinTelegramLevel(userId, minRole) {
  return getUserTelegramLevel(userId) >= ROLE_LEVEL[minRole];
}

// ========== GLOBAL SENDER ==========
let globalSenders = [];

function addSender(userId) {
  if (!globalSenders.includes(userId)) {
    globalSenders.push(userId);
  }
}

bot.on('message', (msg) => {
  const id = msg.from.id;
  addSender(id);
});

// ========== FUNGSI NOTIFIKASI ==========
async function sendGroupNotif(message) {
  try {
    if (!GROUP_NOTIF_ID) {
      logger.warn("GROUP_NOTIF_ID belum diatur - tidak bisa kirim notifikasi grup");
      return;
    }
    await bot.sendMessage(GROUP_NOTIF_ID, message, { parse_mode: "Markdown" });
    logger.info("Notifikasi grup berhasil dikirim");
  } catch (error) {
    logger.error(`Gagal kirim notifikasi grup: ${error.message}`);
  }
}

async function sendOwnerNotif(message) {
  try {
    if (!OWNER_ID) {
      logger.warn("OWNER_ID belum diatur - tidak bisa kirim notifikasi owner");
      return;
    }
    await bot.sendMessage(OWNER_ID, message, { parse_mode: "Markdown" });
    logger.info("Notifikasi owner berhasil dikirim");
  } catch (error) {
    logger.error(`Gagal kirim notifikasi owner: ${error.message}`);
  }
}

async function notifyOwnerNewPasswordFromApp(creatorUsn, createdUsn, password, role = "member", expiredDate) {
  const ownerMsg = `🔐 *NOTIFIKASI PEMBUATAN PASSWORD (DARI APLIKASI)*
👤 Username Pembuat: ${creatorUsn || "Tidak Ditetapkan"}
🆔 Username yang Dibuat: ${createdUsn}
🎯 Role Akun: ${role}
⏳ Masa Aktif: Sampai ${expiredDate}`;
  await sendOwnerNotif(ownerMsg);

  const groupMsg = `⚠️ *PEMBUATAN AKUN (DARI APLIKASI)*
👤 Dibuat oleh: ${creatorUsn || "Tidak Ditetapkan"}
🆔 Username: ${createdUsn}
🎯 Role: ${role}
⏳ Masa Aktif: ${expiredDate}`;
  await sendGroupNotif(groupMsg);
}

// ========== MENU UTAMA (START/MENU) ==========
// ========== MENU UTAMA (START/MENU) ==========
bot.onText(/^\/?(start|menu)/, (msg) => {
  const id = msg.from.id;
  addSender(id);
  
  const userRole = getUserTelegramRole(id);
  const userLevel = getUserTelegramLevel(id);
  
  // CEK APAKAH USER PUNYA AKSES (bukan member/vip biasa)
  const isUnprivileged = userLevel < ROLE_LEVEL['reseller']; // member, vip, atau tanpa role
  
  if (isUnprivileged) {
    // Kirim pesan bahwa mereka tidak punya akses, suruh hubungi owner
    return bot.sendMessage(id, `
❌ *AKSES DITOLAK!*

Halo *${msg.from.first_name}*,

Maaf, Anda tidak memiliki akses ke bot ini.

📋 Status Anda saat ini:
┌─────────────────────────────┐
│ 🆔 ID: \`${id}\`                │
│ 👤 Username: @${msg.from.username || 'tidak ada'} │
│ 🎭 Role: *${userRole.toUpperCase()}* │
└─────────────────────────────┘

📞 Silakan hubungi owner untuk mendapatkan akses:
@dickxmod
    `,  { parse_mode: "Markdown" });
  }
  
  // ========== USER PUNYA AKSES (RESELLER KE ATAS) ==========
  
  // Menu dasar untuk semua user yang punya akses
  let menuButtons = [
    [{ text: "🆕 Buat Akun Member", callback_data: "create_member" }],
    [{ text: "⏳ Set Expired", callback_data: "set_expire" }]
  ];
  
  // Menu untuk reseller ke atas (bisa buat VIP)
  if (userLevel >= ROLE_LEVEL['reseller']) {
    menuButtons.push([{ text: "⭐ Buat Akun VIP", callback_data: "create_vip" }]);
  }
  
  // Menu untuk admin ke atas
  if (userLevel >= ROLE_LEVEL['admin']) {
    menuButtons.push([
      { text: "📦 Buat Akun Reseller", callback_data: "create_reseller" },
      { text: "📋 List User", callback_data: "list_user" }
    ]);
  }
  
  // Menu untuk owner ke atas
  if (userLevel >= ROLE_LEVEL['owner']) {
    menuButtons.push([
      { text: "👑 Buat Akun Admin", callback_data: "create_admin" }
    ]);
  }
  
  // Menu untuk highadmin ke atas
  if (userLevel >= ROLE_LEVEL['highadmin']) {
    menuButtons.push([
      { text: "🛡️ Buat Akun Owner", callback_data: "create_owner" }
    ]);
  }
  
  // Menu untuk ceo
  if (userLevel >= ROLE_LEVEL['ceo'] && userLevel < ROLE_LEVEL['dev']) {
    menuButtons.push([
      { text: "👑 Buat Akun HighAdmin", callback_data: "create_highadmin" }
    ]);
  }

  
  // Menu untuk dev (full akses)
if (userLevel >= ROLE_LEVEL['dev']) {
  menuButtons.push([
    { text: "👑 Buat Akun HighAdmin", callback_data: "create_highadmin" },
    { text: "💻 Buat Akun CEO", callback_data: "create_top" }
  ]);
   menuButtons.push([
    { text: "🗑️ Delete User", callback_data: "delete_user" }
  ]);
  menuButtons.push([
    { text: "🎛 Buat Custom User", callback_data: "create_custom" }
  ]);
}
  
  const options = {
    reply_markup: { inline_keyboard: menuButtons }
  };
  
  // Tambahan info command untuk owner
  let additionalInfo = "";
  if (id === OWNER_ID) {
    additionalInfo = `

🔧 *COMMAND KHUSUS OWNER:*
/addrole <ID> <role> <hari> - Tambah role
/delrole <ID> - Hapus role
/listrole - Lihat semua role
/checkrole - Cek role user
/id - Cek ID sendiri`;
  }
  
  bot.sendMessage(id, `👋 Halo ${msg.from.first_name} (Role: ${userRole.toUpperCase()}), pilih menu:${additionalInfo}`, {
    parse_mode: "Markdown",
    reply_markup: { inline_keyboard: menuButtons }
  });
});

// ========== COMMAND /ADDROLE (HANYA UNTUK OWNER & HANYA ID NUMERIK) ==========
bot.onText(/^\/addrole(?:\s+(.+))?$/, async (msg) => {
  const creatorId = msg.from.id;
  
  // HANYA OWNER_ID yang bisa pakai perintah ini
  if (creatorId !== OWNER_ID) {
    return bot.sendMessage(msg.chat.id, `
❌ *AKSES DITOLAK!*

Anda tidak memiliki izin untuk menggunakan perintah ini.
Hanya *OWNER* yang dapat menambahkan role.

📋 Hubungi owner untuk bantuan.
    `, { parse_mode: "Markdown" });
  }
  
  const text = msg.text.trim();
  const parts = text.split(/\s+/);
  
  // Format: /addrole 123456789 role durasi
  if (parts.length < 3) {
    return bot.sendMessage(msg.chat.id, `
❌ *FORMAT SALAH!*

*Contoh penggunaan:*
\`/addrole 7744011281 dev 300\`
\`/addrole 123456789 admin 30\`

*Penjelasan:*
• ID: ID numerik user Telegram (bisa dapat dari /id)
• Role: dev, admin, owner, ceo, dll
• Durasi: jumlah hari (maksimal 365 hari)

📋 *Daftar Role:*
┌─────────────────────────┐
│ 👤 member    - Member    │
│ ⭐ vip       - VIP       │
│ 📦 reseller  - Reseller  │
│ 👑 admin     - Admin     │
│ 👑 owner     - Owner     │
│ 🛡️ highadmin - High Admin│
│ 👑 ceo       - CEO       │
│ 💻 dev       - Developer │
└─────────────────────────┘

💡 *Tips:* 
Gunakan /id untuk mengetahui ID Anda sendiri
    `, { parse_mode: "Markdown" });
  }
  
  // Ambil parameter
  const targetId = parseInt(parts[1]);
  const targetRole = parts[2].toLowerCase();
  let durationDays = parseInt(parts[3]);
  
  // Validasi ID
  if (isNaN(targetId)) {
    return bot.sendMessage(msg.chat.id, `
❌ *ID TIDAK VALID!*

ID harus berupa angka.
Contoh: \`/addrole 7744011281 dev 300\`

Gunakan /id untuk melihat ID Anda.
    `, { parse_mode: "Markdown" });
  }
  
  // Validasi durasi
  if (isNaN(durationDays) || durationDays <= 0) {
    durationDays = 30;
  }
  if (durationDays > 365) {
    return bot.sendMessage(msg.chat.id, "❌ Durasi maksimal adalah 365 hari!");
  }
  
  // Validasi role
  if (!ROLE_LEVEL[targetRole]) {
    const roleList = Object.keys(ROLE_LEVEL).join(", ");
    return bot.sendMessage(msg.chat.id, `❌ Role "${targetRole}" tidak valid!\n\nRole yang tersedia: ${roleList}`);
  }
  
  // Cek apakah user dengan ID ini valid
  let targetUsername = null;
  try {
    const chat = await bot.getChat(targetId);
    targetUsername = chat.username || targetId.toString();
  } catch (err) {
    targetUsername = targetId.toString();
  }
  
  // Cek apakah user sudah memiliki role
  const existingRole = telegramRoles.get(targetId);
  if (existingRole) {
    // Kirim pesan konfirmasi
    await bot.sendMessage(msg.chat.id, `
⚠️ *PERINGATAN!*

User \`${targetId}\` sudah memiliki role *${existingRole.role.toUpperCase()}*.
Apakah Anda ingin menggantinya dengan role *${targetRole.toUpperCase()}*?

*Balas dengan angka:*
1️⃣ - Ya, ganti role
2️⃣ - Tidak, batalkan

⏰ Timeout 30 detik
    `, { parse_mode: "Markdown" });
    
    // Gunakan mekanisme konfirmasi yang lebih reliable
    let confirmed = false;
    let timeoutId = null;
    
    const confirmationHandler = (responseMsg) => {
      if (responseMsg.from.id === creatorId) {
        const answer = responseMsg.text.trim();
        if (answer === '1' || answer.toLowerCase() === 'ya') {
          confirmed = true;
          if (timeoutId) clearTimeout(timeoutId);
          bot.removeListener('message', confirmationHandler);
        } else if (answer === '2' || answer.toLowerCase() === 'tidak') {
          confirmed = false;
          if (timeoutId) clearTimeout(timeoutId);
          bot.removeListener('message', confirmationHandler);
          bot.sendMessage(msg.chat.id, "❌ Penggantian role dibatalkan.");
        }
      }
    };
    
    // Setup timeout
    const timeoutPromise = new Promise((resolve) => {
      timeoutId = setTimeout(() => {
        bot.removeListener('message', confirmationHandler);
        resolve('timeout');
      }, 30000);
    });
    
    // Setup listener
    bot.on('message', confirmationHandler);
    
    // Tunggu konfirmasi atau timeout
    const result = await Promise.race([
      new Promise((resolve) => {
        const check = setInterval(() => {
          if (confirmed !== false) {
            clearInterval(check);
            resolve(confirmed);
          }
        }, 100);
      }),
      timeoutPromise
    ]);
    
    if (result !== true) {
      return bot.sendMessage(msg.chat.id, "❌ Penggantian role dibatalkan (timeout atau ditolak).");
    }
  }
  
  // Set data role
  const createdAt = Date.now();
  const expiresAt = createdAt + (durationDays * 24 * 60 * 60 * 1000);
  
  telegramRoles.set(targetId, {
    role: targetRole,
    addedBy: creatorId,
    addedAt: createdAt,
    expiresAt: expiresAt,
    durationDays: durationDays,
    username: targetUsername
  });
  saveTelegramRoles();
  
  // Kirim notifikasi ke user yang di-addrole
  try {
    await bot.sendMessage(targetId, `
🎉 *SELAMAT!*

Kamu diangkat menjadi *${targetRole.toUpperCase()}* oleh OWNER

📋 *Detail Role:*
• Role: ${targetRole.toUpperCase()}
• Durasi: ${durationDays} hari
• Berlaku sampai: ${new Date(expiresAt).toLocaleString('id-ID')}

Gunakan /checkrole untuk cek status role kamu.
    `, { parse_mode: "Markdown" });
  } catch (err) {
    console.log(`Tidak bisa mengirim pesan ke ${targetId}: user belum /start`);
  }
  
  // Kirim notifikasi ke GROUP_NOTIF_ID (jika ada)
  if (GROUP_NOTIF_ID) {
    try {
      await bot.sendMessage(GROUP_NOTIF_ID, `
✅ *TAMBAH ROLE*

👤 Target ID: \`${targetId}\`
📛 Username: @${targetUsername}
🎭 Role: *${targetRole.toUpperCase()}*
⏱️ Durasi: ${durationDays} hari
👑 Diubah oleh: OWNER
📅 Expired: ${new Date(expiresAt).toLocaleDateString('id-ID')}
      `, { parse_mode: "Markdown" });
    } catch (err) {}
  }
  
  // Konfirmasi ke tempat perintah dijalankan
  await bot.sendMessage(msg.chat.id, `
✅ *BERHASIL MENAMBAH ROLE!*

┌─────────────────────────────┐
│ 🆔 User ID: \`${targetId}\`     │
│ 📛 Username: @${targetUsername} │
│ 🎭 Role baru: *${targetRole.toUpperCase()}* │
│ ⏱️ Durasi: ${durationDays} hari    │
│ 📅 Expired: ${new Date(expiresAt).toLocaleDateString('id-ID')} │
└─────────────────────────────┘
  `, { parse_mode: "Markdown" });
});

// ========== COMMAND /ID (Cek ID sendiri) ==========
bot.onText(/^\/id$/, async (msg) => {
  const userId = msg.from.id;
  const username = msg.from.username || "tidak ada";
  const firstName = msg.from.first_name || "";
  
  await bot.sendMessage(msg.chat.id, `
📌 *INFO ID ANDA*

🆔 User ID: \`${userId}\`
📛 Username: @${username}
👤 Nama: ${firstName}

💡 *Gunakan ID ini untuk owner:*
\`/addrole ${userId} dev 300\`

*Contoh lain:*
• Jadi admin 30 hari: \`/addrole ${userId} admin 30\`
• Jadi CEO 365 hari: \`/addrole ${userId} ceo 365\`
  `, { parse_mode: "Markdown" });
});

// ========== COMMAND /DELROLE ==========
bot.onText(/^\/delrole(?:\s+(.+))?$/, async (msg) => {
  const deleterId = msg.from.id;
  
  if (!hasMinTelegramLevel(deleterId, 'dev')) {
    return bot.sendMessage(msg.chat.id, "❌ Hanya dev yang bisa menghapus role!");
  }
  
  const args = msg.text.split(" ");
  if (args.length < 2) {
    return bot.sendMessage(msg.chat.id, "❌ Contoh: `/delrole 12345678`", { parse_mode: "Markdown" });
  }
  
  let targetInput = args[1];
  let targetId = null;
  
  if (targetInput.startsWith('@')) {
    try {
      const chatMember = await bot.getChatMember(msg.chat.id, targetInput);
      targetId = chatMember.user.id;
    } catch (err) {
      return bot.sendMessage(msg.chat.id, `❌ Tidak dapat menemukan user ${targetInput}`);
    }
  } else {
    targetId = parseInt(targetInput);
    if (isNaN(targetId)) {
      return bot.sendMessage(msg.chat.id, "❌ ID tidak valid!");
    }
  }
  
  if (!telegramRoles.has(targetId)) {
    return bot.sendMessage(msg.chat.id, `❌ User \`${targetId}\` tidak memiliki role khusus.`, { parse_mode: "Markdown" });
  }
  
  const targetRole = telegramRoles.get(targetId).role;
  const deleterRole = getUserTelegramRole(deleterId);
  
  if (!canCreateTelegramRole(deleterId, targetRole) && deleterRole !== 'dev') {
    return bot.sendMessage(msg.chat.id, `❌ *AKSES DITOLAK!*\n\nRole *${deleterRole.toUpperCase()}* tidak bisa menghapus role *${targetRole.toUpperCase()}*.`, { parse_mode: "Markdown" });
  }
  
  telegramRoles.delete(targetId);
  saveTelegramRoles();
  
  await bot.sendMessage(msg.chat.id, `✅ Role user \`${targetId}\` telah dihapus.`, { parse_mode: "Markdown" });
});

// ========== COMMAND /LISTROLE ==========
bot.onText(/^\/listrole$/, async (msg) => {
  const userId = msg.from.id;
  
  if (!hasMinTelegramLevel(userId, 'dev')) {
    return bot.sendMessage(msg.chat.id, "❌ Hanya admin ke atas yang bisa melihat daftar role!");
  }
  
  if (telegramRoles.size === 0) {
    return bot.sendMessage(msg.chat.id, "📭 Belum ada user yang memiliki role khusus.");
  }
  
  let text = "📋 *DAFTAR USER BY ROLE*\n\n";
  const byRole = {};
  
  for (const [userId, data] of telegramRoles) {
    if (!byRole[data.role]) byRole[data.role] = [];
    byRole[data.role].push({ userId, addedBy: data.addedBy, expiresAt: data.expiresAt });
  }
  
  for (const [role, users] of Object.entries(byRole)) {
    let icon = "👤";
    if (role === 'vip') icon = "⭐";
    else if (role === 'reseller') icon = "📦";
    else if (role === 'admin') icon = "👑";
    else if (role === 'owner') icon = "👑";
    else if (role === 'highadmin') icon = "🛡️";
    else if (role === 'ceo') icon = "👑";
    else if (role === 'dev') icon = "💻";
    
    text += `${icon} *${role.toUpperCase()}* (${users.length})\n`;
    for (const user of users) {
      const expired = user.expiresAt < Date.now() ? "❌ EXPIRED" : "✅ AKTIF";
      text += `   └ \`${user.userId}\` - ${expired}\n`;
    }
    text += "\n";
  }
  
  await bot.sendMessage(msg.chat.id, text, { parse_mode: "Markdown" });
});

// ========== COMMAND /CHECKROLE ==========
bot.onText(/^\/checkrole(?:\s+(.+))?$/, async (msg) => {
  const args = msg.text.split(" ");
  let targetId = msg.from.id;
  
  if (args.length > 1) {
    let targetInput = args[1];
    if (targetInput.startsWith('@')) {
      try {
        const chatMember = await bot.getChatMember(msg.chat.id, targetInput);
        targetId = chatMember.user.id;
      } catch (err) {}
    } else {
      targetId = parseInt(targetInput);
    }
  }
  
  const role = getUserTelegramRole(targetId);
  const roleData = telegramRoles.get(targetId);
  
  let text = `👤 *INFO ROLE*\n\n`;
  text += `🆔 ID: \`${targetId}\`\n`;
  text += `📋 Role: *${role.toUpperCase()}*\n`;
  
  if (roleData) {
    const remainingDays = Math.ceil((roleData.expiresAt - Date.now()) / (1000 * 60 * 60 * 24));
    const isExpired = roleData.expiresAt < Date.now();
    text += `📅 Status: ${isExpired ? "❌ EXPIRED" : `✅ AKTIF (${remainingDays} hari lagi)`}\n`;
    text += `👤 Diberikan oleh: \`${roleData.addedBy}\`\n`;
    text += `⏰ Expired: ${new Date(roleData.expiresAt).toLocaleDateString()}\n`;
  } else {
    text += `📅 Status: Default (member)\n`;
  }
  
  await bot.sendMessage(msg.chat.id, text, { parse_mode: "Markdown" });
});

// ========== COMMAND /LISTSENDER ==========
bot.onText(/\/listsender/, (msg) => {
  let text = "📋 LIST GLOBAL SENDER:\n\n";
  globalSenders.forEach((id, i) => {
    text += `${i + 1}. ${id}\n`;
  });
  bot.sendMessage(msg.chat.id, text || "Kosong");
});

// ========== HANDLER CALLBACK QUERY ==========
bot.on("callback_query", async (query) => {
  const id = query.from.id;
  const data = query.data;
  const isOwner = id === OWNER_ID;
  
  const creatorTelegramUsn = query.from.username ? `@${query.from.username}` : "Tidak Ada";
  const creatorInfo = `${query.from.first_name || 'Pengguna'} (ID: ${id}, Username: ${creatorTelegramUsn})`;
  
  // Role user yang melakukan aksi
  const userRole = getUserTelegramRole(id);
  const userLevel = getUserTelegramLevel(id);
  
  // Helper untuk buat akun berdasarkan role
  const createAccount = async (roleToCreate, allowedRoles) => {
    if (!allowedRoles.includes(userRole) && userRole !== 'dev') {
      return bot.answerCallbackQuery(query.id, { text: `❌ Role ${userRole.toUpperCase()} tidak bisa membuat role ${roleToCreate.toUpperCase()}!` });
    }
    
    bot.sendMessage(id, `Masukkan data untuk akun *${roleToCreate.toUpperCase()}*:\n\`username|password|durasi_hari\``, { parse_mode: "Markdown" });
    bot.once("message", async (msg) => {
      const [createdUsn, password, day] = msg.text.split("|");
      const db = loadDatabase();
      
      if (!createdUsn || !password || !day || isNaN(parseInt(day))) {
        return bot.sendMessage(id, "❌ Format salah! Gunakan: `username|password|durasi_hari`");
      }
      if (db.find(u => u.username === createdUsn)) return bot.sendMessage(id, "❌ Username sudah ada!");
      
      const expired = new Date();
      expired.setDate(expired.getDate() + parseInt(day));
      const expiredDate = expired.toISOString().split("T")[0];
      
      db.push({ username: createdUsn, password, role: roleToCreate, expiredDate });
      saveDatabase(db);
      
      bot.sendMessage(id, `✅ Akun ${roleToCreate} dibuat!\n👤 Username: ${createdUsn}\n⏳ Masa aktif: ${expiredDate}`);
      
      const groupMsg = `⚠️ *PEMBUATAN AKUN BARU*
👤 Dibuat oleh: ${creatorInfo}
🆔 Username: ${createdUsn}
🎯 Role: ${roleToCreate}
⏳ Masa aktif: ${expiredDate}`;
      sendGroupNotif(groupMsg);
    });
  };
  
  switch (data) {
    case "create_member":
      await createAccount("member", ['reseller', 'admin', 'owner', 'highadmin', 'ceo', 'dev']);
      break;
    case "create_vip":
      await createAccount("vip", ['reseller', 'admin', 'owner', 'highadmin', 'ceo', 'dev']);
      break;
    case "create_reseller":
      await createAccount("reseller", ['admin', 'owner', 'highadmin', 'ceo', 'dev']);
      break;
    case "create_admin":
      await createAccount("admin", ['owner', 'highadmin', 'ceo', 'dev']);
      break;
    case "create_owner":
      await createAccount("owner", ['highadmin', 'ceo', 'dev']);
      break;
    case "create_highadmin":
      await createAccount("highadmin", ['ceo', 'dev']);
      break;
    case "create_top":
      if (userRole !== 'dev') {
        return bot.answerCallbackQuery(query.id, { text: "❌ Hanya DEV yang bisa membuat role CEO!" });
      }
      await createAccount("ceo", ['dev']);
      break;
      
    case "set_expire":
      bot.sendMessage(id, "Masukkan: `username|tambah_hari`", { parse_mode: "Markdown" });
      bot.once("message", msg => {
        const [username, addDays] = msg.text.split("|");
        const db = loadDatabase();
        const user = db.find(u => u.username === username);
        if (!user || isNaN(parseInt(addDays))) {
          return bot.sendMessage(id, "❌ Format salah! Gunakan: `username|tambah_hari`");
        }
        const current = new Date(user.expiredDate);
        current.setDate(current.getDate() + parseInt(addDays));
        user.expiredDate = current.toISOString().split("T")[0];
        saveDatabase(db);
        bot.sendMessage(id, `✅ Masa aktif diperbarui untuk ${username} ke ${user.expiredDate}`);
      });
      break;
      
    case "list_user":
      if (!hasMinTelegramLevel(id, 'admin')) {
        return bot.answerCallbackQuery(query.id, { text: "❌ Hanya admin ke atas!" });
      }
      const db = loadDatabase();
      const users = db.length > 0 
        ? db.map(u => `👤 ${u.username} | 🎯 ${u.role || 'member'} | ⏳ ${u.expiredDate}`).join("\n")
        : "ℹ️ Belum ada pengguna terdaftar";
      bot.sendMessage(id, `📋 *Daftar Pengguna:*\n${users}`, { parse_mode: "Markdown" });
      break;
      
    case "delete_user":
      if (!hasMinTelegramLevel(id, 'owner')) {
        return bot.answerCallbackQuery(query.id, { text: "❌ Hanya owner ke atas!" });
      }
      bot.sendMessage(id, "Masukkan username yang akan dihapus:");
      bot.once("message", msg => {
        const db2 = loadDatabase();
        const index = db2.findIndex(u => u.username === msg.text);
        if (index === -1) return bot.sendMessage(id, "❌ User tidak ditemukan.");
        const deleted = db2.splice(index, 1)[0];
        saveDatabase(db2);
        bot.sendMessage(id, `🗑️ User ${deleted.username} berhasil dihapus.`);
      });
      break;
      
case "create_custom":
  // HANYA DEV yang bisa akses
  const userRole = getUserTelegramRole(id);
  if (userRole !== 'dev') {
    return bot.answerCallbackQuery(query.id, { 
      text: "❌ AKSES DITOLAK! Fitur 'Buat Custom User' hanya untuk DEVELOPER.", 
      show_alert: true 
    });
  }
  
  bot.sendMessage(id, `
📝 *BUAT CUSTOM USER (DEV ONLY)*

Masukkan data dengan format:
\`username|password|role|durasi_hari\`

*Contoh:*
\`johndoe|pass123|ceo|30\`

📋 *Role yang tersedia:*
member, vip, reseller, admin, owner, highadmin, ceo, dev

⏱️ *Durasi:* 1-365 hari
  `, { parse_mode: "Markdown" });
  
  bot.once("message", async (msg) => {
    if (msg.from.id !== id) return;
    
    const [createdUsn, password, role, day] = msg.text.split("|");
    const db = loadDatabase();
    
    if (!createdUsn || !password || !role || !day || isNaN(parseInt(day))) {
      return bot.sendMessage(id, "❌ Format salah! Gunakan: `username|password|role|durasi_hari`");
    }
    
    const expired = new Date();
    expired.setDate(expired.getDate() + parseInt(day));
    const expiredDate = expired.toISOString().split("T")[0];
    
    db.push({ 
      username: createdUsn, 
      password, 
      role: role.toLowerCase(), 
      expiredDate 
    });
    saveDatabase(db);
    
    bot.sendMessage(id, `✅ *CUSTOM USER BERHASIL DIBUAT!*\n\n👤 Username: ${createdUsn}\n🎭 Role: ${role}\n⏳ Expired: ${expiredDate}`, { parse_mode: "Markdown" });
  });
  break;
      
    // Di dalam handler callback_query, hapus atau ubah case ini:

case "addrole_menu":
  if (id !== OWNER_ID) {
    return bot.answerCallbackQuery(query.id, { text: "❌ Hanya OWNER yang bisa menggunakan fitur ini! Gunakan command /addrole" });
  }
  bot.sendMessage(id, `
🔧 *CARA MENAMBAH ROLE*

Gunakan command:
\`/addrole ID_USER role durasi\`

*Contoh:*
\`/addrole 7744011281 dev 300\`
\`/addrole 123456789 admin 30\`

📋 *Daftar Role:* member, vip, reseller, admin, owner, highadmin, ceo, dev

💡 *Tips:* 
• Minta user ketik /id untuk mengetahui ID mereka
• Durasi maksimal 365 hari
  `, { parse_mode: "Markdown" });
  break;
  
case "listrole_menu":
  if (id !== OWNER_ID) {
    return bot.answerCallbackQuery(query.id, { text: "❌ Hanya OWNER yang bisa melihat daftar role! Gunakan command /listrole" });
  }
  bot.sendMessage(id, "🔧 Gunakan command `/listrole` untuk melihat daftar semua user yang memiliki role.", { parse_mode: "Markdown" });
  break;
      
    default:
      bot.answerCallbackQuery(query.id, { text: "Fitur dalam pengembangan" });
  }
  
  bot.answerCallbackQuery(query.id);
});
// ========== CEK EXPIRED OTOMATIS ==========
setInterval(() => {
  let changed = false;
  const now = Date.now();
  for (const [userId, data] of telegramRoles) {
    if (data.expiresAt < now) {
      telegramRoles.delete(userId);
      changed = true;
    }
  }
  if (changed) saveTelegramRoles();
}, 60 * 60 * 1000);

// ========== START BOT ==========
function startTelegramBot() {
  loadTelegramRoles();
  console.log("Telegram bot started");
  
  const restartTime = new Date().toLocaleString('id-ID', { 
    timeZone: 'Asia/Makassar',
    year: 'numeric', month: 'long', day: 'numeric',
    hour: '2-digit', minute: '2-digit', second: '2-digit'
  });
  sendOwnerNotif(`🔄 *SERVER/BOT RESTARTED*\n📅 Waktu: ${restartTime}`);
}

module.exports = {
  bot,
  startTelegramBot,
  notifyOwnerNewPasswordFromApp
};